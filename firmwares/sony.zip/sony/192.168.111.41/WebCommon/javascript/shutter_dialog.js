// JavaScript Document

function ShutterDialog(objAttachSrc, arrItems, nDftSelect, funcCallback, objName)
{
	this.AttachSrc = objAttachSrc;
	this.Items = arrItems;
	this.SelectedIndex = nDftSelect;
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	
	var m_objSelf = this;
	var m_Object = null;
	var m_objCurrentItem = null;
	var m_ObjTitle = null;
	var m_IsTouchMoving = false;
	var m_ObjItemArea = null;
	var m_objOldItem = null;
	
	var m_TouchMoveValue = 0;
	var m_ShutterTouchMoveTime = 0;
	
	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		divMainContainer.className = "DIV_DLG_MAIN";
		GetParent(this.AttachSrc).appendChild(divMainContainer);
		divMainContainer.style.display = "none";
		m_Object = divMainContainer;
	
		var divTitle = document.createElement("DIV");
		divTitle.className = "DIV_DLG_TITLE";
		divMainContainer.appendChild(divTitle);
		m_ObjTitle = divTitle;
		
		var divArrow = document.createElement("DIV");
		divArrow.className = "DIV_DLG_LEFT_ARROW";
		divMainContainer.appendChild(divArrow);
		
		var divTopSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.left= "16px";
		divTopSeparator.style.top = "37px";
		divMainContainer.appendChild(divTopSeparator);
		
		var divSubSelect = document.createElement("DIV");
		divSubSelect.className = "DIV_DLG_SUB";
		divMainContainer.appendChild(divSubSelect);
		
		var divMainBottomSeparator = document.createElement("DIV");
		divMainBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divMainBottomSeparator.style.top = "288px";
		divSubSelect.appendChild(divMainBottomSeparator);
		
		var divSelectArea = document.createElement("DIV");
		divSelectArea.className = "DIV_DLG_ITEMAREA";
		divSubSelect.appendChild(divSelectArea);
		m_ObjItemArea = divSelectArea;
		//add own scroll event
     	AddEvent(divSelectArea, "touchstart", this.CallbackTouchStart);
		AddEvent(divSelectArea, "touchmove", this.CallbackMainItemTouchMove);
		AddEvent(divSelectArea, "touchend", this.CallbackItemClick);
		divSelectArea.style.overflowY = "auto";
		
		for (var i = 0; i < this.Items.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.className = "DIV_DLG_SHUTTER_ITEM";
			divItem.style.top = (i * 48) + "px";
			divItem.innerHTML = this.Items[i];
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			
			AddEvent(divItem, "click", this.CallbackItemClick);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseout", this.CallbackItemMouseOut);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			
			if (this.SelectedIndex == i)
			{
				m_objCurrentItem = divItem;
				divItemIcon.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_SelectMark_Serected.png)";
			}
			
			divItem.appendChild(divItemIcon);
			divSelectArea.appendChild(divItem);
		}
		
		if (m_objSelf.Items.length < 6)
		{
			for (var i = m_objSelf.Items.length; i < 6; i++)
			{
				var divItem = document.createElement("DIV");
				divItem.className = "DIV_DLG_SHUTTER_ITEM";
				divItem.style.top = (i * 48) + "px";
			
				if (i % 2 == 0)
				{
					j(divItem).css("background-color","rgb(28,28,28)");
				}
			
				m_ObjItemArea.appendChild(divItem);
			}
		}
		
		var divStepCancelButton = document.createElement("DIV");
		divStepCancelButton.className = "DIV_DLG_BUTTON";
		divStepCancelButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divStepCancelButton.innerHTML = "Cancel";
		divStepCancelButton.style.left = -9 + "px";
		divStepCancelButton.style.top = 287 + "px";
		
		AddEvent(divStepCancelButton, "click", this.CallbackButtonClick);
		AddEvent(divStepCancelButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(divStepCancelButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divStepCancelButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divStepCancelButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divStepCancelButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divStepCancelButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(divStepCancelButton, "touchcancel", this.CallbackBtnTouchEnd);
		divSubSelect.appendChild(divStepCancelButton);
		
		var divStepOKButton = document.createElement("DIV");
		divStepOKButton.className = "DIV_DLG_BUTTON";
		divStepOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divStepOKButton.innerHTML = "OK";
		divStepOKButton.style.left = 176 + "px";
		divStepOKButton.style.top = 287 + "px";
		
		AddEvent(divStepOKButton, "click", this.CallbackButtonClick);
		AddEvent(divStepOKButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(divStepOKButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divStepOKButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divStepOKButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divStepOKButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divStepOKButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(divStepOKButton, "touchcancel", this.CallbackBtnTouchEnd);
		divSubSelect.appendChild(divStepOKButton);
		
		divMainContainer.style.left = parseInt(this.AttachSrc.style.left) + 228 + "px";
		divMainContainer.style.top = parseInt(this.AttachSrc.style.top) - 186 + "px";
	}
	
	this.ShowDialog = function()
	{
		clearInterval(m_ShutterTouchMoveTime);
		m_ShutterTouchMoveTime = 0;
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";
			return;
		}
		
		if (m_Object.style.display == "block")
		{
			m_Object.style.display = "none";
		}
		else
		{
			m_Object.style.display = "block";
		}
		var objSelectedItem = $(m_objSelf.SelectedIndex + "_" + this.NameID + "_DLG_ITEM");
		if (m_objCurrentItem)
		{
			m_objCurrentItem.children[0].style.backgroundImage = "";
			m_objCurrentItem.style.color = "rgb(230,230,230)";
		}
		if (objSelectedItem)
		{
			objSelectedItem.children[0].style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_SelectMark_Serected.png)";
			objSelectedItem.style.color = "rgb(255,170,0)";
			m_objCurrentItem = objSelectedItem;
			m_objOldItem = objSelectedItem;
		}
		
		var iItemNum = parseInt(m_objCurrentItem.id);
		var iItemHeight = j(m_objCurrentItem).height();
		var iScrollLength = iItemHeight*iItemNum;
		j('.DIV_DLG_ITEMAREA').scrollTop(iScrollLength); 
	}
	
	this.CallbackItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";
		if(m_ShutterTouchMoveTime == 0) {
			m_ShutterTouchMoveTime = setInterval(m_objSelf.JudgeTouchMoveEvent, 150);
		}
	};
	
	this.CallbackItemTouchEnd = function(objEvent)
	{
		clearInterval(m_ShutterTouchMoveTime);
		m_ShutterTouchMoveTime = 0;
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objCurrentItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}	
	};
		
	this.CallbackItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;//select nothing, return is safe.
		}
		
		if (objSrc.style.opacity == "0.2")
		{
			return;
		}
		
		m_objCurrentItem.children[0].style.backgroundImage = "";
		m_objCurrentItem.style.color = "rgb(230, 230, 230)";
		
		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_objCurrentItem = objSrc;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_objCurrentItem = GetParent(objSrc);
		}
		
		if (null != m_objSelf.CallbackFunc) 
		{
			var strSelectedValue = m_objSelf.Items[parseInt(m_objCurrentItem.id, 10)];
			m_objSelf.CallbackFunc(m_objSelf.AttachSrc, strSelectedValue);
		}
	};
	
	this.CallbackItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objCurrentItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};

	this.CallbackItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objCurrentItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}		
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		m_Object.style.display = "none";
		
		if (null != m_objSelf.CallbackFunc) {
			if (0 == parseInt(objSrc.id))
			{
				var strSelectedValue = m_objSelf.Items[parseInt(m_objOldItem.id, 10)];
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, strSelectedValue, "ShutterCancel");

			}else
			{
				
				//var strSelectedValue = m_objSelf.Items[parseInt(m_objCurrentItem.id, 10)];
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, -1, "ShutterOk");
			}
		}
	};
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Pressed.png)";
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{	
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";

		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Pressed.png)";

	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		clearInterval(m_ShutterTouchMoveTime);
		m_ShutterTouchMoveTime = 0;
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
		m_Object.style.display = "none";
		
		if (null != m_objSelf.CallbackFunc) {
			if (0 == parseInt(objSrc.id))
			{
				var strSelectedValue = m_objSelf.Items[parseInt(m_objOldItem.id, 10)];
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, strSelectedValue, "ShutterCancel");

			}else
			{
				//var strSelectedValue = m_objSelf.Items[parseInt(m_objCurrentItem.id, 10)];
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, -1, "ShutterOk");
			}
		}
			
	};
	
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.SetSelect = function(selectedValue)
	{
		m_objSelf.SelectedIndex = j.inArray(selectedValue, m_objSelf.Items);//return index in array

		/*var objSelectedItem = $(m_objSelf.SelectedIndex + "_" + this.NameID + "_DLG_ITEM");
		if(objSelectedItem != m_objCurrentItem)
		{
			if (m_objCurrentItem)
			{
				m_objCurrentItem.children[0].style.backgroundImage = "";
				m_objCurrentItem.style.color = "rgb(230,230,230)";
			}
			if (objSelectedItem)
			{
				objSelectedItem.children[0].style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_SelectMark_Serected.png)";
				objSelectedItem.style.color = "rgb(255,170,0)";
				m_objCurrentItem = objSelectedItem;
			}
		}*/
	};
	
	this.SetListItems = function(arrItems)
	{
		if (arrItems == m_objSelf.Items)
		{
			return;
		}
		m_objSelf.DeleteOldDlgItemsDIV();
		m_objSelf.Items = arrItems;

		for (var i = 0; i < m_objSelf.Items.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.className = "DIV_DLG_SHUTTER_ITEM";
			divItem.style.top = (i * 48) + "px";
			divItem.innerHTML = this.Items[i];
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			
			AddEvent(divItem, "click", this.CallbackItemClick);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseout", this.CallbackItemMouseOut);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			
			divItem.appendChild(divItemIcon);
			m_ObjItemArea.appendChild(divItem);
		}
		
		if (m_objSelf.Items.length < 6)
		{
			for (var i = m_objSelf.Items.length; i < 6; i++)
			{
				var divItem = document.createElement("DIV");
				divItem.className = "DIV_DLG_SHUTTER_ITEM";
				divItem.style.top = (i * 48) + "px";
			
				if (i % 2 == 0)
				{
					j(divItem).css("background-color","rgb(28,28,28)");
				}
			
				m_ObjItemArea.appendChild(divItem);
			}
		}
	}
	
	this.DeleteOldDlgItemsDIV = function()
	{
		for (var i = 0; i <m_objSelf.Items.length; i++)
		{
			var deleteItem = $(i + "_" + m_objSelf.NameID + "_DLG_ITEM");
			
			RemoveEvent(deleteItem, "click", this.CallbackItemClick);
			RemoveEvent(deleteItem, "mousedown", this.CallbackItemMouseDown);
			RemoveEvent(deleteItem, "mouseout", this.CallbackItemMouseOut);
			RemoveEvent(deleteItem, "mouseup", this.CallbackItemMouseUp);
			RemoveEvent(deleteItem, "touchstart", this.CallbackItemTouchStart);	
			RemoveEvent(deleteItem, "touchend", this.CallbackItemTouchEnd);
			RemoveEvent(deleteItem, "touchcancel", this.CallbackItemTouchEnd);
			j(deleteItem).remove();
		}
		
		if (m_objSelf.Items.length < 6)
		{
			for (var i = m_objSelf.Items.length; i < 6; i++)
			{
				var deleteItem = $(i + "_" + m_objSelf.NameID + "_DLG_ITEM");
				j(deleteItem).remove();
			}
		}
	}
	
	this.CallbackTouchStart = function(objEvent)
	{
		m_TouchMoveValue = objEvent.touches[0].pageY;
		scrollStartPos = this.scrollTop + objEvent.touches[0].pageY;//get first touchDown position.
		objEvent.preventDefault();
		m_IsTouchMoving = false;	
	}; 
	
	this.JudgeTouchMoveEvent = function()
	{
		if (m_TouchMoveValue < 5 && m_TouchMoveValue > -5)
		{
			m_IsTouchMoving = false;
		}
		else
		{
			m_IsTouchMoving = true;
		}
	};

	this.CallbackMainItemTouchMove = function(objEvent)
	{
		m_TouchMoveValue = m_TouchMoveValue - objEvent.touches[0].pageY;
		objEvent.preventDefault();
		if (m_IsTouchMoving)
		{
			//change current touchdown item's scrollTop in 
			this.scrollTop = scrollStartPos - objEvent.touches[0].pageY;
		}
	};
	
	this.GrayPartsOfItems = function(standardValue)
	{
		var tempValue;
		for (var i = 0; i < this.Items.length; ++i)
		{
			tempValue = this.Items[i].substr(2,this.Items[i].length-1);
			var tempObjItem = $(i + "_" + this.NameID + "_DLG_ITEM");
			if (tempValue < standardValue)
			{
				tempObjItem.style.opacity = 0.2;
				RemoveEvent(tempObjItem, "click", this.CallbackItemClick);
				//RemoveEvent(j(".DIV_DLG_SHUTTER_ITEM"), "mouseover", this.CallbackItemMouseOver);
				//RemoveEvent(j(".DIV_DLG_SHUTTER_ITEM"), "mouseout", this.CallbackItemMouseOut);
				RemoveEvent(tempObjItem, "mousedown", this.CallbackItemMouseDown);
				RemoveEvent(tempObjItem, "mouseup", this.CallbackItemMouseUp);
				RemoveEvent(tempObjItem, "touchstart", this.CallbackItemTouchStart);	
				RemoveEvent(tempObjItem, "touchend", this.CallbackItemTouchEnd);
				RemoveEvent(tempObjItem, "touchcancel", this.CallbackItemTouchEnd);
			}
			else
			{
				tempObjItem.style.opacity = 1;
				AddEvent(tempObjItem, "click", this.CallbackItemClick);
				//AddEvent(j(".DIV_DLG_SHUTTER_ITEM"), "mouseover", this.CallbackItemMouseOver);
				//AddEvent(j(".DIV_DLG_SHUTTER_ITEM"), "mouseout", this.CallbackItemMouseOut);
				AddEvent(tempObjItem, "mousedown", this.CallbackItemMouseDown);
				AddEvent(tempObjItem, "mouseup", this.CallbackItemMouseUp);
				AddEvent(tempObjItem, "touchstart", this.CallbackItemTouchStart);	
				AddEvent(tempObjItem, "touchend", this.CallbackItemTouchEnd);
				AddEvent(tempObjItem, "touchcancel", this.CallbackItemTouchEnd);
			}
		}
	}
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};
	
	this.ClearTimer = function()
	{
		clearInterval(m_ShutterTouchMoveTime);
		m_ShutterTouchMoveTime = 0;
	};
	
	this.Create();
}
