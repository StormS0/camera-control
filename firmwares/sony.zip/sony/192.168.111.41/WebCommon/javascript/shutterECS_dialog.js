// JavaScript Document

function ShutterECSDialog(objAttachSrc, nDftSelect, funcCallback, objName)
{
	this.AttachSrc = objAttachSrc;
	this.CallBackFunc = funcCallback;
	this.NameID = objName;
	
	var m_objSelf = this;
	var m_CurValue = nDftSelect;
	var m_OldValue = nDftSelect;
	var mutil = [-15, -5, -1, 0, 1, 5, 15];
	var mutilNum = 7;
	var m_ObjText = null;
	var m_Object = null;
	var m_Slider = null;
	var m_objPlusBtn = null;
	var m_objMinusBtn = null;
	
	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		divMainContainer.className = "DIV_DLG_MAIN";
		GetParent(this.AttachSrc).appendChild(divMainContainer);
		divMainContainer.style.display = "none";
		m_Object = divMainContainer;
		
		var divTitle = document.createElement("DIV");
		divTitle.className = "DIV_DLG_TITLE";
		divMainContainer.appendChild(divTitle);
		m_ObjTitle = divTitle;
		m_ObjTitle.innerHTML = "Shutter";
		
		var divArrow = document.createElement("DIV");
		divArrow.className = "DIV_DLG_LEFT_ARROW";
		divMainContainer.appendChild(divArrow);
		
		var divTopSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.left= "16px";
		divTopSeparator.style.top = "37px";
		divMainContainer.appendChild(divTopSeparator);
		
		var divSubSelect = document.createElement("DIV");
		divSubSelect.className = "DIV_DLG_SUB";
		divMainContainer.appendChild(divSubSelect);
		
		var divTextField= document.createElement("DIV");
		divTextField.className = "DIV_DLG_TEXT_FIELD";
		divTextField.id = "0_DIV_" + this.NameID + "_DLG_TEXTFIELD";
		divTextField.style.top = "76px";
		divSubSelect.appendChild(divTextField);
		m_ObjText = divTextField;

		var divMinusBtn = document.createElement("DIV");
		divMinusBtn.id = "4_DIV_" + this.NameID + "_DLG_BTN";
		divMinusBtn.className = "DIV_DLG_MINUS_BTN";
		divMinusBtn.style.top = "80px";
		divSubSelect.appendChild(divMinusBtn);
		var arrMinusBtnImgs = ["Parts_CR_T_CC_Spinner_Button_Minus_Normal", "Parts_CR_T_CC_Spinner_Button_Minus_Pressed", "Parts_CR_T_CC_Spinner_Button_Minus_Normal", "Parts_CR_T_CC_Spinner_Button_Minus_Normal", ""];
		divMinusBtn.userData = new ButtonCtrl(divMinusBtn, arrMinusBtnImgs, this.PlusOrMinisButtonClick);
		m_objMinusBtn = divMinusBtn;
			
		var divPlusBtn = document.createElement("DIV");
		divPlusBtn.id = "5_DIV_" + this.NameID + "_DLG_BTN";
		divPlusBtn.className = "DIV_DLG_PLUS_BTN";
		divPlusBtn.style.top = "80px";
		divSubSelect.appendChild(divPlusBtn);
		var arrPlusBtnImgs = ["Parts_CR_T_CC_Spinner_Button_Plus_Normal", "Parts_CR_T_CC_Spinner_Button_Plus_Pressed", "Parts_CR_T_CC_Spinner_Button_Plus_Normal", "Parts_CR_T_CC_Spinner_Button_Plus_Normal", ""];
		divPlusBtn.userData = new ButtonCtrl(divPlusBtn, arrPlusBtnImgs, this.PlusOrMinisButtonClick);
		m_objPlusBtn = divPlusBtn;
		
		var lblMiddlePic = document.createElement("DIV");
		lblMiddlePic.className = "LBL_PICKER_SPIRNG_SCALE_MIDDLE_DLG";
		divSubSelect.appendChild(lblMiddlePic);
	
		//slider
		var divSliderGroove = document.createElement("DIV");
		divSliderGroove.className = "DIV_PICKER_SPE_GROOVE_DLG";
		divSliderGroove.style.top = "200px";
		divSubSelect.appendChild(divSliderGroove);
		
		var divSlider = document.createElement("DIV");
		divSlider.id = "DIV_PICKER_ZOOM_SLIDER_" + this.NameID;
		divSlider.className = "DIV_PICKER_SPRING_SLIDER_DLG";
		divSlider.style.top = "182px";
		divSlider.style.left = "105px";
		divSubSelect.appendChild(divSlider);
		m_Slider = divSlider;
		
		divSlider.userData = new Array();
		divSlider.userData[0] = new FocusBackSlider(divSlider, mutil, mutilNum, this.sliderCallBack);
		
		var divMainBottomSeparator = document.createElement("DIV");
		divMainBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divMainBottomSeparator.style.top = "288px";
		divSubSelect.appendChild(divMainBottomSeparator);
	
		var divCanelButton = document.createElement("DIV");
		divCanelButton.className = "DIV_DLG_BUTTON";
		divCanelButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divCanelButton.innerHTML = "Cancel";
		divCanelButton.style.left = -9 + "px";
		divCanelButton.style.top = 286 + "px";

		
		AddEvent(divCanelButton, "click", this.CallbackButtonClick);
		AddEvent(divCanelButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divCanelButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divCanelButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divCanelButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divCanelButton, "touchend", this.CallbackBtnTouchEnd);	
		AddEvent(divCanelButton, "touchcancel", this.CallbackBtnTouchEnd);
		divSubSelect.appendChild(divCanelButton);
		
		var divOKButton = document.createElement("DIV");
		divOKButton.className = "DIV_DLG_BUTTON";
		divOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divOKButton.style.left = 176 + "px";
		divOKButton.style.top = 286 + "px";
		divOKButton.innerHTML = "OK";
		
		AddEvent(divOKButton, "click", this.CallbackButtonClick);
		AddEvent(divOKButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divOKButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divOKButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divOKButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divOKButton, "touchend", this.CallbackBtnTouchEnd);	
		AddEvent(divOKButton, "touchcancel", this.CallbackBtnTouchEnd);
		divSubSelect.appendChild(divOKButton);

		divMainContainer.style.left = parseInt(this.AttachSrc.style.left) + 228  + "px";
		divMainContainer.style.top = parseInt(this.AttachSrc.style.top) - 186 + "px";
	};
	
	this.ShowDialog = function()
	{

		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";
			return;
		}
		
		if("block" == m_Object.style.display) {
			m_Object.style.display = "none";
		}
		else {
			m_Object.style.display = "block";
			m_OldValue = m_CurValue;
		}
	}
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		m_Object.style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
				
				m_objSelf.CallBackFunc(objSrc, m_OldValue);
				break;
			case 1:
				m_objSelf.CallBackFunc(objSrc, 0);
				break;
			default:
				break;
		}
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		if((0 == parseInt(objSrc.id)) || (1 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Pressed.png)";
		}
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
		m_Object.style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
				m_objSelf.CallBackFunc(objSrc, m_OldValue);
				break;
			case 1:
				m_objSelf.CallBackFunc(objSrc, 0);
				break;
			default:
				break;
		}
		
	};
	
	this.CallbackButtonMouseOver = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if((0 == parseInt(objSrc.id)) || (1 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
		}
	};
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objSrc.style.color = "rgb(230,230,230)";
		if((0 == parseInt(objSrc.id)) || (1 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
		}
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(0,0,0)";
		if((0 == parseInt(objSrc.id)) || (1 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Pressed.png)";
		}
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(230,230,230)";
		if((0 == parseInt(objSrc.id)) || (1 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Normal.png)";
		}
	};
	
	this.PlusOrMinisButtonClick = function(objSrc)
	{
		m_objSelf.CallBackFunc(objSrc, 0);
	};
		
	this.sliderCallBack = function(value)
	{
		if (((value > 0) && (0.2 != m_objPlusBtn.style.opacity))
			||((value < 0) && (0.2 != m_objMinusBtn.style.opacity)))
		{
			if (null != m_objSelf.CallBackFunc) 
			{
				m_objSelf.CallBackFunc(m_Slider, value);
			}
		}
	};
	
	this.SetPlusMinusButtonDisabled = function (strBtnName,bGray)
	{
		if ("plus" == strBtnName)
		{
			m_objPlusBtn.userData.SetDisabled(bGray);
			m_objPlusBtn.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Plus_Normal.png)";
		}else if ("minus" == strBtnName) 
		{
			m_objMinusBtn.userData.SetDisabled(bGray);
			m_objMinusBtn.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Spinner_Button_Minus_Normal.png)";
		}else 
		{
		}
		
	};
	
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.SetSelect = function(selectValue)
	{
		m_ObjText.innerHTML = selectValue;
		m_CurValue = selectValue;
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};
	
	
	this.Create();
}