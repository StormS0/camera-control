// JavaScript Document
var IrisReturn = 378;

function IrisSlider(objSrc, objCallback)
{
	var Iris_x = 0;
	var IrisCurrent_X = 0;
	var IrisMin_x = 122;
	var IrisMax_x = 574;
	//var Iris_Array = [122,134,148,162,180,198,216,234,252,270,288,306,324,342,360,378,396,414,432,450,486,522,574];
	var Iris_Array = [122,125,126,127,131,134,139,142,149,155,165,171,186,195,217,230,256,276,321,347,399,439,530,574];
	var Value_Array = [0.7,0.9,1,1.1,1.4,1.6,2,2.2,2.8,3.2,4,4.5,5.6,6.3,8,9,11,12.5,16,18,22,25,32,35.4];
	var IrisMouseDown = false;
	var IrisTouchStart = false;
	this.Parent = GetParent(objSrc);
	this.AttachSrc = objSrc;
	this.Width = parseInt(objSrc.style.width);
	this.CallbackFunc = objCallback;
	this.Type = "SLIDER";
	var m_objSelf = null;
	var blank = 0;
	var b_IsTouchMouseStart = false;
	IrisCurrent_X = j(objSrc).position().left;
	var defaultX = j(objSrc).position().left;
	var iCurrentLeft = j(objSrc).css("left");
	Iris_x = j(objSrc).position().left;
	var iMousemove_PreviousX = -1;
	var iMousemove_CurrentX = -1;
//	var g_PosXMapTickValue = {122:0.9,134:1,148:1.1,162:1.4,180:1.6,198:2,216:2.2,234:2.8,252:3.2,270:4,288:4.5,306:5.6,324:6.3,342:8,360:9,378:11,396:12.5,414:16,432:18,450:22,486:25,522:32,574:35.4};
	var g_PosXMapTickValue = {122:0.7,125:0.9,126:1,127:1.1,131:1.4,134:1.6,139:2,142:2.2,149:2.8,155:3.2,165:4,171:4.5,186:5.6,195:6.3,217:8,230:9,256:11,276:12.5,321:16,347:18,399:22,439:25,530:32,574:35.4};
	var iCurrentLeft = j(objSrc).css("left");
	
	
	this.Initialize = function()
	{
		if (!m_objSelf)
		{
			m_objSelf = this;
		    AddEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		    AddEvent(document, "mousemove", this.CallbackBtnMouseMove);
		    AddEvent(document, "mouseup", this.CallbackBtnMouseUp);
		    AddEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
		    AddEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			AddEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
			AddEvent(this.AttachSrc, "touchcancel", this.CallbackBtnTouchCancel);
			
		}
		
	};
		
	//Mouse Event
	this.CallbackBtnMouseDown = function(objEvent)
	{
		IrisMouseDown = true;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		IrisCurrent_X = j(objSrc).position().left;
		iMousemove_PreviousX = objEvent.pageX;
		iCurrentLeft = j(objSrc).css("left");
		b_IsTouchMouseStart = true;
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris_Pressed.png)";
		return false;
	};

	this.CallbackBtnMouseMove = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if(!b_IsTouchMouseStart) 
		{
			return false;
		}
		iMousemove_CurrentX = objEvent.pageX;
		IrisCurrent_X += iMousemove_CurrentX - iMousemove_PreviousX;
		iMousemove_PreviousX = objEvent.pageX;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		else
		{
			//it's nothing to do
		}
		
		//gray when dragging
		iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
		var minDirection = 1000;
		var minIndex = -1;
		for (var i = 0; i < Iris_Array.length; ++i)
		{
			if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
			{
				minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
				minIndex = i;
			}
		}
		IrisReturn = Iris_Array[minIndex];
		m_objSelf.IrisMouseChangeValue();
	
		j("#IRIS_SLIDER_HANDLE").css({left: IrisCurrent_X, backgroundImage:"URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris_Pressed.png)"});	
		
		
		return false;
		
	};
	
	this.CallbackBtnMouseUp = function(objEvent)
	{
		IrisMouseDown = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris.png)"});
				
		   IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];
		   IrisCtrl.SetValue();
		   b_IsTouchMouseStart = false;
		   return false;
		}
	};
	
	
	//Touch Event
	this.CallbackBtnTouchStart = function(objEvent)
	{	
		IrisTouchStart = true;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		var touch = objEvent.touches[0];
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		IrisCurrent_X = touch.screenX;
		defaultX = j(objSrc).position().left;
		blank = IrisCurrent_X - defaultX;
		IrisCurrent_X -= blank;
		iMousemove_PreviousX = touch.screenX;
		iCurrentLeft = j(objSrc).css("left");
		m_objSelf.IrisTouchChangeValue();
		b_IsTouchMouseStart = true;
		objSrc.style.backgroundImage = "URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris_Pressed.png)";
		return false;
	};
	
	this.CallbackBtnTouchMove = function(objEvent)
	{	
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();	
		var touch = objEvent.touches[0];
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if(!b_IsTouchMouseStart) 
		{
			return false;
		}
		
		iMousemove_CurrentX = touch.screenX;
		IrisCurrent_X += iMousemove_CurrentX - iMousemove_PreviousX;
		Iris_x = touch.screenX - blank;
		iMousemove_PreviousX = touch.screenX;
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		else
		{
			//it's nothing to do
		}

		iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
		var minDirection = 1000;
		var minIndex = -1;
		for (var i = 0; i < Iris_Array.length; ++i)
		{
			if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
			{
				minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
				minIndex = i;
			}
		}
		IrisReturn = Iris_Array[minIndex];
		j("#IRIS_SLIDER_HANDLE").css({left: IrisCurrent_X});
		m_objSelf.IrisTouchChangeValue();
		return false;
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		IrisTouchStart = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris.png)"});
			
			IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];	
			IrisCtrl.SetValue();
			
		    b_IsTouchMouseStart = false;
		    return false;
		}
	};
	
	this.CallbackBtnTouchCancel = function(objEvent)
	{
		IrisTouchStart = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(WebCommon/images/Parts_CR_T_CC_Rec_Slider_Knob_Iris.png)"});
		
			IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];	
			IrisCtrl.SetValue();
		
		    b_IsTouchMouseStart = false;
		    return false;
		}
	}
	
	this.CallbackBtnClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
	
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		if (m_objSelf.CallbackFunc)
		{
			m_objSelf.CallbackFunc(m_objSelf.AttachSrc);
		}
	};
	
	this.IrisTouchChangeValue = function()
	{
		var i = 0;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		
		for (i = 0; i < 25; i++)
		{
			if (Iris_x == Iris_Array[i])
			{
				IrisValue = Value_Array[i];
			}
			
			if (Iris_x > Iris_Array[i] && Iris_x <= Iris_Array[i + 1])
			{
				IrisValue = Value_Array[i + 1];
			}
		}
		IrisCtrl.SetValue();
	}
	
	this.IrisMouseChangeValue = function()
	{
		var i = 0;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		
		for (i = 0; i < 25; i++)
		{
			if (IrisCurrent_X == Iris_Array[i])
			{
				IrisValue = Value_Array[i];
			}
			
			if (IrisCurrent_X > Iris_Array[i] && IrisCurrent_X <= Iris_Array[i + 1])
			{
				IrisValue = Value_Array[i + 1];
			}
		}
		//j("#DIV_IRIS_VALUE").text("F" + IrisValue);
		IrisCtrl.SetValue();
		
	}
	
	this.SetDisabled = function(bDisabled)
	{
	
		if (bDisabled)
		{

			if (IrisMouseDown)
			{
				this.CallbackBtnMouseUp();
				
			}
			if (IrisTouchStart)
			{
				this.CallbackBtnTouchEnd();
			}
			RemoveEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		    RemoveEvent(document, "mousemove", this.CallbackBtnMouseMove);
		    RemoveEvent(document, "mouseup", this.CallbackBtnMouseUp);
			RemoveEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
			RemoveEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			RemoveEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
			
		}
		else
		{
			 AddEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		     AddEvent(document, "mousemove", this.CallbackBtnMouseMove);
		     AddEvent(document, "mouseup", this.CallbackBtnMouseUp);
		     AddEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
			 AddEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			 AddEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
		
		}
	}
	
	this.Initialize();
}
