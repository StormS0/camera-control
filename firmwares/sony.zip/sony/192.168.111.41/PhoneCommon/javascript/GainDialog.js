// JavaScript Document
function GainDialog(objSrc, arrItems, CurrentValue, funcCallback, objName)
{
	this.ObjSrc = objSrc;
	this.Items = arrItems;
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	
	var m_ObjSelf = this;
	var m_CurrentIndex = -1;
	var m_ObjTitle = null;
	var m_objOldItem = null ;
	var m_Object = null;
	var m_ObjItemArea = null;
	var m_CurrentValue = CurrentValue;
	var m_OldValue = null;
	var scrollStartPos = 0;
	var m_IsTouchMoving = false;
	
	var m_TouchMoveValue = 0;
	var m_GainTouchMoveTime = 0;
	
	this.Create = function () 
	{
		var divMainContainer = document.createElement("DIV");
		divMainContainer.className = "DIV_DLG_MAIN";
		divMainContainer.style.display = "none";
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);
		m_Object = divMainContainer;

		var divTitleContainer = document.createElement("DIV");
		divTitleContainer.className = "DIV_DLG_TITLE";
		divMainContainer.appendChild(divTitleContainer);
		m_ObjTitle = divTitleContainer;
		
		var divSubContainer = document.createElement("DIV");
		divSubContainer.className = "DIV_DLG_SUB";
		divMainContainer.appendChild(divSubContainer);

		var divTopSeparator = document.createElement("DIV");
		var divBottomSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		
		divTopSeparator.style.top = "-1px";
		divBottomSeparator.style.top = "265px";
		
		divSubContainer.appendChild(divTopSeparator);
		divSubContainer.appendChild(divBottomSeparator);	
		var divItemsContainer = document.createElement("DIV");
		divItemsContainer.className = "DIV_DLG_ITEMAREA";
		divSubContainer.appendChild(divItemsContainer);
		m_ObjItemArea = divItemsContainer;

		//add touch event to divItemsContainer to scroll
		AddEvent(divItemsContainer, "touchstart", this.CallbackTouchStart);
		AddEvent(divItemsContainer, "touchmove", this.CallbackMainItemTouchMove);
		AddEvent(divItemsContainer, "touchend", this.CallbackItemClick);
		divItemsContainer.style.overflowY = "auto";

		for (var i = 0;i < this.Items.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			divItem.className = "DIV_DLG_GAIN_ITEM";
			divItem.style.top = (i * 44) + "px";
			divItem.innerHTML = this.Items[i]
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			AddEvent(divItem, "click", this.CallbackItemClick);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			divItemIcon.id = 11 + "_" + this.NameID + "_DLG_ITEM_ICON";
			divItem.appendChild(divItemIcon);
			
			if (m_CurrentValue == j(divItem).text())
			{
				m_objOldItem = divItem;
				divItemIcon.style.backgroundImage = "url(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divItemIcon.style.backgroundRepeat = "no-repeat";
				divItem.style.color = "rgb(255,170,0)";
				m_CurrentIndex = i;
			}
			divItemsContainer.appendChild(divItem);
		}
		/***************** OK and Cancel Button ****************************/
		var divOkButton = document.createElement("DIV");
		divOkButton.id = "1_DIV_" + this.NameID + "_DLG_BTN"
		divOkButton.className = "DIV_DLG_BUTTON";
		divOkButton.style.left = 158 + "px";
		divOkButton.style.top = 266 + "px";
		this.AddButtonEvent(divOkButton, "OK")
		divSubContainer.appendChild(divOkButton);
		
		var divCancelButton = document.createElement("DIV");
		divCancelButton.id = "0_DIV_" + this.NameID + "_DLG_BTN"
		divCancelButton.className = "DIV_DLG_BUTTON";
		divCancelButton.style.left = -4 + "px";
		divCancelButton.style.top = 266 + "px";
		this.AddButtonEvent(divCancelButton, "Cancel")
		divSubContainer.appendChild(divCancelButton);
	};

	this.AddButtonEvent = function(objButton, strButtonText)
	{
		AddEvent(objButton, "click", this.CallbackButtonClick);
		AddEvent(objButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(objButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(objButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(objButton, "mouseup", this.CallbackButtonMouseUp);
		AddEvent(objButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(objButton, "touchend", this.CallbackBtnTouchEnd);	
		AddEvent(objButton, "touchcancel", this.CallbackBtnTouchCancel);
		objButton.style.opacity = 1;
		objButton.innerHTML = strButtonText;
	};
	
	this.ShowDialog = function ()
	{
		clearInterval(m_GainTouchMoveTime);
		m_GainTouchMoveTime = 0;
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			return;
		}
		
		if("block" == m_Object.style.display) {
    		m_Object.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else {
			m_Object.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
		}
		
		var objSelectedItem = $(m_CurrentIndex + "_" + this.NameID + "_DLG_ITEM");
		if (m_objOldItem)
		{
			m_objOldItem.children[0].style.backgroundImage = "";
			m_objOldItem.style.color = "rgb(230,230,230)";
		}
		if (objSelectedItem)
		{
			objSelectedItem.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSelectedItem.style.color = "rgb(255,170,0)";
			m_objOldItem = objSelectedItem;
		}
		m_OldValue = m_ObjSelf.Items[m_CurrentIndex];
		
		//Foucs on current selected Item
		var iItemNum = parseInt(m_objOldItem.id);
		var iItemHeight = j(m_objOldItem).height();
		var iScrollLength = iItemHeight*iItemNum;
		j(m_ObjItemArea).scrollTop(iScrollLength);
	};

	this.CallbackTouchStart = function(objEvent)
	{
		m_TouchMoveValue = objEvent.touches[0].pageY;
		scrollStartPos = this.scrollTop + objEvent.touches[0].pageY;//get first touchDown position.
		objEvent.preventDefault();
		m_IsTouchMoving = false; 
	}; 
	
	this.JudgeTouchMoveEvent = function()
	{
		if (m_TouchMoveValue < 5 && m_TouchMoveValue > -5)
		{
			m_IsTouchMoving = false;
		}
		else
		{
			m_IsTouchMoving = true;
		}
	};

	this.CallbackMainItemTouchMove = function(objEvent)
	{
		m_TouchMoveValue = m_TouchMoveValue - objEvent.touches[0].pageY;
		objEvent.preventDefault();
		if (m_IsTouchMoving)
		{
			//change current touchdown item's scrollTop in 
			this.scrollTop = scrollStartPos - objEvent.touches[0].pageY;
		}
	};
	
	this.CallbackItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;//if not, it will select nothing when scroll the scrollbar.
		}

		if (objSrc != null)
		{
			objSrc.style.color = "rgb(255,170,0)";
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			if ((m_objOldItem != null)&&(m_objOldItem != objSrc))
			{
				m_objOldItem.style.color = "rgb(230,230, 230)";
				m_objOldItem.children[0].style.backgroundImage = "";
			}
			m_objOldItem = objSrc ;
			if (null != m_ObjSelf.CallbackFunc)
			{
				m_ObjSelf.CallbackFunc($("TEXT_DIV_GAIN"), j(objSrc).text());
			}
		}
	};
	
	this.CallbackItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objOldItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";
		if(m_GainTouchMoveTime == 0) {
			m_GainTouchMoveTime = setInterval(m_ObjSelf.JudgeTouchMoveEvent, 150);
		}
	};
	
	this.CallbackItemTouchEnd = function(objEvent)
	{
		clearInterval(m_GainTouchMoveTime);
		m_GainTouchMoveTime = 0;
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objOldItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		m_Object.style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
				if (null != m_ObjSelf.CallbackFunc)
				{
					m_ObjSelf.CallbackFunc($("TEXT_DIV_GAIN"), m_OldValue);
				}
				break;
			case 1:
			break;
		}
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			g_OldObject = null;
	};
	
	this.CallbackButtonMouseOver = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (objSrc.id == "")
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		
	};
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";	
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{	
		var objSrc = GetEventSource(objEvent);
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
	    objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		clearInterval(m_GainTouchMoveTime);
		m_GainTouchMoveTime = 0;
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		g_OldObject = null;
	};
	
	this.SetTitle = function(currentTitle)
	{
		m_ObjTitle.innerHTML = currentTitle;
	};
	
	this.SetSelect = function(currentValue)
	{
		m_CurrentValue = currentValue;
		var i = 0;
		for(; i< this.Items.length; ++i)
		{
			if(currentValue == m_ObjSelf.Items[i]) break;
		}
		m_CurrentIndex = i;
	};
	
	this.SetArrItems = function(GainItems)
	{
		if(this.Items == GainItems)
		{
			return false;
		}
		this.Items = GainItems;
		this.SelectedValue = GainItems[m_CurrentIndex];
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "click", this.CallbackItemClick);
		//RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "mouseover", this.CallbackItemMouseOver);
		//RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "mouseout", this.CallbackItemMouseOut);
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "mousedown", this.CallbackItemMouseDown);
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "mouseup", this.CallbackItemMouseUp);
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "touchstart", this.CallbackItemTouchStart);	
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "touchend", this.CallbackItemTouchEnd);
		RemoveEvent(j(".DIV_DLG_GAIN_ITEM"), "touchcancel", this.CallbackItemTouchEnd);
		j(".DIV_DLG_GAIN_ITEM").remove();

		for (var i = 0;i < this.Items.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			divItem.className = "DIV_DLG_GAIN_ITEM"
			divItem.style.top = (i * 44) + "px";
			divItem.innerHTML = this.Items[i];
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			divItemIcon.id = 11 + "_" + this.NameID + "_DLG_ITEM_ICON";
			divItem.appendChild(divItemIcon);
			
			if (m_CurrentValue == j(divItem).text())
			{
				m_objOldItem = divItem;
				divItemIcon.style.backgroundImage = "url(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divItemIcon.style.backgroundRepeat = "no-repeat";
				divItem.style.color = "rgb(255,170,0)";
				m_CurrentIndex = i;
			}
			AddEvent(divItem, "click", this.CallbackItemClick);
			//AddEvent(divItem, "mouseover", this.CallbackItemMouseOver);
			//AddEvent(divItem, "mouseout", this.CallbackItemMouseOut);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			m_ObjItemArea.appendChild(divItem);
		}
	};

	//Foucs on current selected Item
	this.ContainerMove = function(nMovePreIndex, nFlag)
	{
		var nMoveValue = nFlag * parseInt($(nMovePreIndex + "_GAIN_DLG_ITEM").style.top);
		m_nContainerTop = nMoveValue;
		if(nMovePreIndex == 8)
		{
			j(document).scrollTop(48);
		}
		if (m_nContainerTop <= m_nMoveMinTop)
		{
			m_nContainerTop = m_nMoveMinTop;
		}
		j("#DIV_DLG_SUB").animate({scrollTop: m_nContainerTop}, 400);
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};

	this.ClearTimer = function()
	{
		clearInterval(m_GainTouchMoveTime);
		m_GainTouchMoveTime = 0;
	};
	
	this.Create();
}
