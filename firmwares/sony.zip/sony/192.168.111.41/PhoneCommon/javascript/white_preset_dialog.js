// JavaScript Document
function WhitePresetDialog(objSrc, CurrentValue, funcCallback, objName)
{
	this.ObjSrc = objSrc;
	this.Items = ["Preset3200K", "Preset4300K", "Preset5500K"];
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	
	var m_ObjSelf = this;
	var m_CurrentIndex = -1;
	var m_ObjTitle = null;
	var m_objOldItem = null ;
	var m_Object = null;
	var m_ObjItemArea = null;
	var m_CurrentValue = "Preset3200K";
	var m_OldValue = null;
	var scrollStartPos = 0;
	var m_IsTouchMoving = false;
	var m_SelectItem = null;
	
	this.Create = function () 
	{
		var divMainContainer = document.createElement("DIV");
		divMainContainer.className = "DIV_DLG_MAIN";
		divMainContainer.style.display = "none";
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);
		m_Object = divMainContainer;

		var divTitleContainer = document.createElement("DIV");
		divTitleContainer.className = "DIV_DLG_TITLE";
		divMainContainer.appendChild(divTitleContainer);
		m_ObjTitle = divTitleContainer;
		
		var divSubContainer = document.createElement("DIV");
		divSubContainer.className = "DIV_DLG_SUB";
		divMainContainer.appendChild(divSubContainer);

		var divTopSeparator = document.createElement("DIV");
		var divBottomSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		
		divTopSeparator.style.top = "-1px";
		divBottomSeparator.style.top = "265px";
		
		divSubContainer.appendChild(divTopSeparator);
		divSubContainer.appendChild(divBottomSeparator);	
		var divItemsContainer = document.createElement("DIV");
		divItemsContainer.className = "DIV_DLG_ITEMAREA";
		divSubContainer.appendChild(divItemsContainer);
		m_ObjItemArea = divItemsContainer;

		//add touch event to divItemsContainer to scroll
		AddEvent(divItemsContainer, "touchstart", this.CallbackTouchStart);
		AddEvent(divItemsContainer, "touchmove", this.CallbackMainItemTouchMove);
		AddEvent(divItemsContainer, "touchend", this.CallbackItemClick);
		divItemsContainer.style.overflowY = "auto";

		for (var i = 0;i < this.Items.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			divItem.className = "DIV_DLG_PREWHITE_ITEM";
			divItem.style.top = (i * 44) + "px";
			divItem.innerHTML = this.Items[i]
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			AddEvent(divItem, "click", this.CallbackItemClick);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			divItemIcon.id = 11 + "_" + this.NameID + "_DLG_ITEM_ICON";
			divItem.appendChild(divItemIcon);
			
			if (m_CurrentValue == j(divItem).text())
			{
				m_objOldItem = divItem;
				m_SelectItem = divItem;
				divItemIcon.style.backgroundImage = "url(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divItemIcon.style.backgroundRepeat = "no-repeat";
				divItem.style.color = "rgb(255,170,0)";
				m_CurrentIndex = i;
			}
			divItemsContainer.appendChild(divItem);
		}
		
		if (this.Items.length < 6)
		{
			for (var i = this.Items.length; i < 6; i++)
			{
				var divItem = document.createElement("DIV");
				divItem.className = "DIV_DLG_PREWHITE_ITEM";
				divItem.style.top = (i * 44) + "px";
				divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
				if (i % 2 == 0)
				{
					j(divItem).css("background-color","rgb(28,28,28)");
				}
				divItemsContainer.appendChild(divItem);
			}
		}
		/***************** OK and Cancel Button ****************************/
		var divOkButton = document.createElement("DIV");
		divOkButton.id = "1_DIV_" + this.NameID + "_DLG_BTN"
		divOkButton.className = "DIV_DLG_BUTTON";
		divOkButton.style.left = 158 + "px";
		divOkButton.style.top = 266 + "px";
		this.AddButtonEvent(divOkButton, "OK")
		divSubContainer.appendChild(divOkButton);
		
		var divCancelButton = document.createElement("DIV");
		divCancelButton.id = "0_DIV_" + this.NameID + "_DLG_BTN"
		divCancelButton.className = "DIV_DLG_BUTTON";
		divCancelButton.style.left = -4 + "px";
		divCancelButton.style.top = 266 + "px";
		this.AddButtonEvent(divCancelButton, "Cancel")
		divSubContainer.appendChild(divCancelButton);
	};

	this.AddButtonEvent = function(objButton, strButtonText)
	{
		AddEvent(objButton, "click", this.CallbackButtonClick);
		AddEvent(objButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(objButton, "mouseup", this.CallbackButtonMouseUp);
		AddEvent(objButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(objButton, "touchend", this.CallbackBtnTouchEnd);	
		AddEvent(objButton, "touchcancel", this.CallbackBtnTouchCancel);
		objButton.style.opacity = 1;
		objButton.innerHTML = strButtonText;
	};
	
	this.ShowDialog = function ()
	{
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			return;
		}
		
		if("block" == m_Object.style.display) {
    		m_Object.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else {
			m_Object.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
		}
		
		var objSelectedItem = $(m_CurrentIndex + "_" + this.NameID + "_DLG_ITEM");
		if (m_objOldItem)
		{
			m_objOldItem.children[0].style.backgroundImage = "";
			m_objOldItem.style.color = "rgb(230,230,230)";
		}
		if (objSelectedItem)
		{
			objSelectedItem.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSelectedItem.style.color = "rgb(255,170,0)";
			m_objOldItem = objSelectedItem;
		}
		m_OldValue = m_ObjSelf.Items[m_CurrentIndex];
		m_SelectItem = objSelectedItem;
		
		//Foucs on current selected Item
		var iItemNum = parseInt(m_objOldItem.id);
		var iItemHeight = j(m_objOldItem).height();
		var iScrollLength = iItemHeight*iItemNum;
		j(m_ObjItemArea).scrollTop(iScrollLength);
	};

	this.CallbackTouchStart = function(objEvent)
	{
		scrollStartPos = this.scrollTop + objEvent.touches[0].pageY;//get first touchDown position.
		objEvent.preventDefault();
		m_IsTouchMoving = false; 
	}; 

	this.CallbackMainItemTouchMove = function(objEvent)
	{
		//change current touchdown item's scrollTop in 
		this.scrollTop = scrollStartPos - objEvent.touches[0].pageY;
		objEvent.preventDefault();
		m_IsTouchMoving = true;
	};
	
	this.CallbackItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;//if not, it will select nothing when scroll the scrollbar.
		}

		if (objSrc != null)
		{
			objSrc.style.color = "rgb(255,170,0)";
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			if ((m_SelectItem != null)&&(m_SelectItem != objSrc))
			{
				m_SelectItem.style.color = "rgb(230,230, 230)";
				m_SelectItem.children[0].style.backgroundImage = "";
			}
			
			if (null != m_ObjSelf.CallbackFunc)
			{
				m_SelectItem = objSrc;
				m_ObjSelf.CallbackFunc(objSrc, j(objSrc).text().substr(0,10));
			}
		}
	};
	
	this.CallbackItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objOldItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objOldItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		m_Object.style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
				if (null != m_ObjSelf.CallbackFunc)
				{
					m_objOldItem = m_SelectItem;
					m_ObjSelf.CallbackFunc(objSrc, m_OldValue.substr(0,10));
				}
				break;
			case 1:
				if (null != m_ObjSelf.CallbackFunc)
				{
					m_objOldItem = m_SelectItem;
					m_ObjSelf.CallbackFunc(objSrc, "", "", "Ok");
				}
			break;
		}
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";	
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{	
		var objSrc = GetEventSource(objEvent);
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objEvent.preventDefault();
		objSrc.style.color = "rgb(0,0,0)";
	    objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	
		m_Object.style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
				if (null != m_ObjSelf.CallbackFunc)
				{
					m_objOldItem = m_SelectItem;
					m_ObjSelf.CallbackFunc(objSrc, m_OldValue.substr(0,10));
				}
				break;
			case 1:
				if (null != m_ObjSelf.CallbackFunc)
				{
					m_objOldItem = m_SelectItem;
					m_ObjSelf.CallbackFunc(objSrc, "", "", "Ok");
				}
			break;
		}
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
	};
	
	this.CallbackBtnTouchCancel = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	
	};
	
	this.SetTitle = function(currentTitle)
	{
		m_ObjTitle.innerHTML = currentTitle;
	};
	
	this.SetSelect = function(currentValue)
	{
		m_CurrentValue = currentValue + "K";
		for(var i = 0; i< m_ObjSelf.Items.length; i++)
		{
			if(m_CurrentValue == m_ObjSelf.Items[i]) 
			{
				m_CurrentIndex = i;
				break;
			}
		}
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};

	this.Create();
}
