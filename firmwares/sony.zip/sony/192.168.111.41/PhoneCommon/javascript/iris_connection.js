// JavaScript Document

var IrisValue = 5.6;
var g_bIrisGray = false;
var IsIrisClose = false;
var IrisValue1 = 0;
var Irispre1 = 0;
var Irisnext1 = -1;
var Irispre2 = 0;
var Irisnext2 = -1;
var g_IrisEnabled = true;

var IrisCtrl = {
	

	GetValue : function()
	{
		var  assignValueItems = new Array();
		var names = {"Camera.Iris.Value":null,"Camera.Iris.Close.Enabled":null, "Camera.Iris.Value.Enabled":null};
		//var Iris_Array = [60,67,73,77,86,94,102,108,117,126,133,138,148,156,163,169,179,187,195,201,210,218,226,232,262];
		//var Iris_Array = [60,67,73,77,86,94,102,108,117,126,133,138,148,156,163,169,179,187,195,201,210,236,262];
		var Iris_Array = [60,61,62,63,64,65,68,69,72,75,79,82,89,93,102,108,120,129,149,161,184,201,242,262];
		//var Value_Array = [1.6,1.7,1.8,2,2.2,2.4,2.6,2.8,3.1,3.4,3.7,4,4.4,4.8,5.2,5.6,6.2,6.8,7.3,8,8.7,9.6,10,11,12];
		var Value_Array = [0.7,0.9,1,1.1,1.4,1.6,2,2.2,2.8,3.2,4,4.5,5.6,6.3,8,9,11,12.5,16,18,22,25,32,35.4];
		
		var id = client.property.GetValue({params: names,
		onresponse: function(resp) {
			
			var respIris = JSON.stringify(resp.error || resp.result);
			var IrisData = JSON.parse(respIris);
			
			if (IrisData == "timeout")
			{
					
			}
			else
			{
				IrisValue1 = IrisData["Camera.Iris.Value"];
				IsIrisClose = IrisData["Camera.Iris.Close.Enabled"];
				g_IrisEnabled = IrisData["Camera.Iris.Value.Enabled"];
				if (g_IrisEnabled == false)
				{
					g_ObjIrisValue.innerHTML = "---";
				}
				if (g_LensMountValue != "Disconnected" && g_IrisEnabled == true)
				{
					if (IsIrisClose == "true" || IsIrisClose == true)
					{	
						g_ObjIrisValue.innerHTML = "Close";
					}
					else
					{	
						if ( IrisValue1 == 2 || IrisValue1 == 4 || IrisValue1 == 8 || IrisValue1 == 11 || IrisValue1 == 10 )
						{
							g_ObjIrisValue.innerHTML = "F" + IrisValue1;
						}
						else
						{
							g_ObjIrisValue.innerHTML = "F" + Irisplusone(IrisValue1);
						}
					}

					for (var i = 0; i < Value_Array.length; i++)
					{
						if (Irisplusone(IrisValue1) == Value_Array[i])
						{
							IrisReturn = Iris_Array[i];
						}
					}
				
					j("#IRIS_SLIDER_HANDLE").css({left: IrisReturn, backgroundImage:"URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris.png)"});
				}
			
			}
	
		}});

	},
	
	SetValue : function()
	{
		var names = {"Camera.Iris.Value":linear.todouble(IrisValue),"Camera.Iris.Close.Enabled":IsIrisClose};
		var id = client.property.SetValue({params: names,
		onresponse: function(resp) {
											
		}})
	},
	GetStatus : function ()
	{
		var names = {"P.Control.u2x500.Iris":null};
		
		var id = client.property.GetStatus({params: names,
			onresponse: function(resp) {
				var resp_str = JSON.stringify(resp.error || resp.result);
				var respData = JSON.parse(resp_str);
				if (respData == "timeout")
				{		
				}
				else
				{
					var strIrisLocked = respData["P.Control.u2x500.Iris"];
					
					if(strIrisLocked == "Locked")
					{
						g_bIrisGray = true;	
					}
					else 
					{
						g_bIrisGray = false;
					}
					IrisGrayFunction(g_bIrisGray, g_LockFlag);
				}
			},
			timeout:3000});
	},

	NotifySetIrisData : function(objArrItem)
	{
		j.each(objArrItem, function(key, value) 
		{
			if ("Camera.Iris.Close.Enabled" == key)
			{
				IsIrisClose = value;
			}
			
			if ("Camera.Iris.Value" == key)
			{
				IrisValue1 = value;
				if (g_LensMountValue != "Disconnected" && g_IrisEnabled == true)
				{
					if (IsIrisClose == "true" || IsIrisClose == true)
					{
						g_ObjIrisValue.innerHTML = "Close";
					}
					else
					{
						if ( IrisValue1 == 2 || IrisValue1 == 4 || IrisValue1 == 8 || IrisValue1 == 11 || IrisValue1 == 10 )
						{
							g_ObjIrisValue.innerHTML = "F" + IrisValue1;
						}
						else
						{
							g_ObjIrisValue.innerHTML = "F" + Irisplusone(IrisValue1);
						}
					}
				}
			}
			if ("Camera.Iris.Value.Enabled" == key)
			{
				g_IrisEnabled = value;
				if (!g_IrisEnabled)
				{
					g_ObjIrisValue.innerHTML = "---";
				}
			}
			
			if ("P.Menu.pmw-f5x.Event.EventID" == key)
			{
				if (value == EVENT_THUMBNAIL_UPDATE || 
					value == EVENT_PLAY_UPDATE || 
					value == EVENT_RECORDE_UPDATE || 
					value == EVENT_VIEW_UPDATE || 
					value == EVENT_IRISPOSITION_NOTIFY_DISPLAY ||
					value == EVENT_700P_CONNECTION_STATUS_REFRESH_WIFI ||
					value == EVENT_IRISAUTOMODE_NOTIFY_DISPLAY ||
					value == EVENT_ATTACHLENS_NOTIFY_LENSEXTENDER_UPDATE)
				{
					IrisCtrl.GetStatus();
				}
			}
			
		})
	},
	
	SetIrisText : function()
	{
		if (IsIrisClose == "true" || IsIrisClose == true)
		{
			g_ObjIrisValue.innerHTML = "Close";
		}
		else
		{
			if ( IrisValue1 == 2 || IrisValue1 == 4 || IrisValue1 == 8 || IrisValue1 == 11 || IrisValue1 == 10 )
			{
				g_ObjIrisValue.innerHTML = "F" + IrisValue1;
			}
			else
			{
				g_ObjIrisValue.innerHTML = "F" + Irisplusone(IrisValue1);
			}
		}
	}
}
