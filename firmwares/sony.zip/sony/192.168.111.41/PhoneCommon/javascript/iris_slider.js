// JavaScript Document
var IrisReturn = 171;

function IrisSlider(objSrc, objCallback)
{
	var Iris_x = 0;
	var IrisCurrent_X = 0;
	var IrisMin_x = 60;
	var IrisMax_x = 262;
	//var Iris_Array = [60,67,73,77,86,94,102,108,117,126,133,138,148,156,163,169,179,187,195,201,210,236,262];
	var Iris_Array = [60,61,62,63,64,65,68,69,72,75,79,82,89,93,102,108,120,129,149,161,184,201,242,262];
	//var Value_Array = [1.6,1.7,1.8,2,2.2,2.4,2.6,2.8,3.1,3.4,3.7,4,4.4,4.8,5.2,5.6,6.2,6.8,7.3,8,8.7,9.6,10,11,12];
	var Value_Array = [0.7,0.9,1,1.1,1.4,1.6,2,2.2,2.8,3.2,4,4.5,5.6,6.3,8,9,11,12.5,16,18,22,25,32,35.4];
	var IrisMouseDown = false;
	var IrisTouchStart = false;
	this.Parent = GetParent(objSrc);
	this.AttachSrc = objSrc;
	this.Width = parseInt(objSrc.style.width);
	this.CallbackFunc = objCallback;
	this.Type = "SLIDER";
	var m_objSelf = null;
	var blank = 0;
	var b_IsTouchMouseStart = false;
	IrisCurrent_X = j(objSrc).position().left;
	var defaultX = j(objSrc).position().left;
	var iCurrentLeft = j(objSrc).css("left");
	Iris_x = j(objSrc).position().left;;
	var iMousemove_PreviousX = -1;
	var iMousemove_CurrentX = -1;
//	var g_PosXMapTickValue = {60:0.9,67:1,73:1.1,77:1.4,86:1.6,94:2,102:2.2,108:2.8,117:3.2,126:4,133:4.5,138:5.6,148:6.3,156:8,163:9,169:11,179:12.5,187:16,195:18,201:22,210:25,236:32,262:35.4};
	var g_PosXMapTickValue = {60:0.7,61:0.9,62:1,63:1.1,64:1.4,65:1.6,68:2,69:2.2,72:2.8,75:3.2,79:4,82:4.5,89:5.6,93:6.3,102:8,108:9,120:11,129:12.5,149:16,161:18,184:22,201:25,242:32,262:35.4};
	var iCurrentLeft = j(objSrc).css("left");
	
	this.Initialize = function()
	{
		if (!m_objSelf)
		{
			m_objSelf = this;
		    AddEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		    AddEvent(document, "mousemove", this.CallbackBtnMouseMove);
		    AddEvent(document, "mouseup", this.CallbackBtnMouseUp);
		    AddEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
		    AddEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			AddEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
			AddEvent(this.AttachSrc, "touchcancel", this.CallbackBtnTouchCancel);
		}
		
	};
		
	//Mouse Event
	this.CallbackBtnMouseDown = function(objEvent)
	{
		IrisMouseDown = true;
		objEvent.preventDefault();
		var objSrc = GetEventSource(objEvent);
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		IrisCurrent_X = j(objSrc).position().left;
		iMousemove_PreviousX = objEvent.pageX;
		iCurrentLeft = j(objSrc).css("left");
		b_IsTouchMouseStart = true;
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris_Pressed.png)";
		return false;
	};

	this.CallbackBtnMouseMove = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if(!b_IsTouchMouseStart) 
		{
			return false;
		}
		iMousemove_CurrentX = objEvent.pageX;
		IrisCurrent_X += iMousemove_CurrentX - iMousemove_PreviousX;
		iMousemove_PreviousX = objEvent.pageX;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		else
		{
			//it's nothing to do
		}
		
		//gray when dragging
		iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
		var minDirection = 1000;
		var minIndex = -1;
		for (var i = 0; i < Iris_Array.length; ++i)
		{
			if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
			{
				minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
				minIndex = i;
			}
		}
		IrisReturn = Iris_Array[minIndex];
		m_objSelf.IrisMouseChangeValue();
		
		j("#IRIS_SLIDER_HANDLE").css({left: IrisCurrent_X, backgroundImage:"URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris_Pressed.png)"});	
		
		return false;
		
	};
	
	this.CallbackBtnMouseUp = function(objEvent)
	{
		IrisMouseDown = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris.png)"});
				
		   IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];
		   IrisCtrl.SetValue();
		   b_IsTouchMouseStart = false;
		   return false;
		}
	};
	
	
	//Touch Event
	this.CallbackBtnTouchStart = function(objEvent)
	{	
		IrisTouchStart = true;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		var touch = objEvent.touches[0];
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		IrisCurrent_X = touch.screenX;
		defaultX = j(objSrc).position().left;
		blank = IrisCurrent_X - defaultX;
		IrisCurrent_X -= blank;
		iMousemove_PreviousX = touch.screenX;
		iCurrentLeft = j(objSrc).css("left");
		m_objSelf.IrisTouchChangeValue();
		b_IsTouchMouseStart = true;
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris_Pressed.png)";
		return false;
	};
	
	this.CallbackBtnTouchMove = function(objEvent)
	{	
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();	
		var touch = objEvent.touches[0];
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if(!b_IsTouchMouseStart) 
		{
			return false;
		}
		
		iMousemove_CurrentX = touch.screenX;
		IrisCurrent_X += iMousemove_CurrentX - iMousemove_PreviousX;
		Iris_x = touch.screenX - blank;
		iMousemove_PreviousX = touch.screenX;
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		else
		{
			//it's nothing to do
		}

		iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
		var minDirection = 1000;
		var minIndex = -1;
		for (var i = 0; i < Iris_Array.length; ++i)
		{
			if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
			{
				minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
				minIndex = i;
			}
		}
		IrisReturn = Iris_Array[minIndex];
		j("#IRIS_SLIDER_HANDLE").css({left: IrisCurrent_X});
		m_objSelf.IrisTouchChangeValue();
		return false;
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		IrisTouchStart = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris.png)"});
			
			IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];	
			IrisCtrl.SetValue();
			
		    b_IsTouchMouseStart = false;
		    return false;
		}
	};
	
	this.CallbackBtnTouchCancel = function(objEvent)
	{
		IrisTouchStart = false;
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		if (b_IsTouchMouseStart)
		{
			iCurrentLeft = j("#IRIS_SLIDER_HANDLE").css("left");
			var minDirection = 1000;
			var minIndex = -1;
			
			for (var i = 0; i < Iris_Array.length; ++i)
			{
				if (minDirection >= Math.abs(Iris_Array[i]-parseInt(iCurrentLeft)))
				{
					minDirection = Math.abs(Iris_Array[i]-parseInt(iCurrentLeft));
					minIndex = i;
				}
			}
			
			
			j("#IRIS_SLIDER_HANDLE").css({left:Iris_Array[minIndex], backgroundImage:"URL(PhoneCommon/images/Parts_CR_S_CC_Rec_Slider_Knob_Iris.png)"});
			
			IrisValue = g_PosXMapTickValue[Iris_Array[minIndex]];	
			IrisCtrl.SetValue();
			
		    b_IsTouchMouseStart = false;
		    return false;
		}
	}
	
	this.CallbackBtnClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		
		if (m_objSelf.CallbackFunc)
		{
			m_objSelf.CallbackFunc(m_objSelf.AttachSrc);
		}
	};
	
	this.IrisTouchChangeValue = function()
	{
		var i = 0;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		
		for (i = 0; i < 25; i++)
		{
			if (Iris_x == Iris_Array[i])
			{
				IrisValue = Value_Array[i];
			}
			
			if (Iris_x > Iris_Array[i] && Iris_x <= Iris_Array[i + 1])
			{
				IrisValue = Value_Array[i + 1];
			}
		}
		IrisCtrl.SetValue();
	}
	
	this.IrisMouseChangeValue = function()
	{
		var i = 0;
		
		if (IrisCurrent_X < IrisMin_x)
		{
			IrisCurrent_X = IrisMin_x;
		}
		else if (IrisCurrent_X > IrisMax_x)
		{
			IrisCurrent_X = IrisMax_x;
		}
		
		for (i = 0; i < 25; i++)
		{
			if (IrisCurrent_X == Iris_Array[i])
			{
				IrisValue = Value_Array[i];
			}
			
			if (IrisCurrent_X > Iris_Array[i] && IrisCurrent_X <= Iris_Array[i + 1])
			{
				IrisValue = Value_Array[i + 1];
			}
		}
		//j("#DIV_IRIS_VALUE").text("F" + IrisValue);
		IrisCtrl.SetValue();
		
	}
	
	this.SetDisabled = function(bDisabled)
	{
	
		if (bDisabled)
		{

			if (IrisMouseDown)
			{
				this.CallbackBtnMouseUp();
				
			}
			if (IrisTouchStart)
			{
				this.CallbackBtnTouchEnd();
			}
			RemoveEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		    RemoveEvent(document, "mousemove", this.CallbackBtnMouseMove);
		    RemoveEvent(document, "mouseup", this.CallbackBtnMouseUp);
			RemoveEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
			RemoveEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			RemoveEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
			
		}
		else
		{
			 AddEvent(this.AttachSrc, "mousedown", this.CallbackBtnMouseDown);
		     AddEvent(document, "mousemove", this.CallbackBtnMouseMove);
		     AddEvent(document, "mouseup", this.CallbackBtnMouseUp);
		     AddEvent(this.AttachSrc, "touchstart", this.CallbackBtnTouchStart);	
			 AddEvent(this.AttachSrc, "touchmove", this.CallbackBtnTouchMove);	
			 AddEvent(this.AttachSrc, "touchend", this.CallbackBtnTouchEnd);
		
		}
	}
	
	this.Initialize();
}
