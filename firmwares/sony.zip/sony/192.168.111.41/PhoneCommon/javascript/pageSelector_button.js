// JavaScript Document
function PageSeletor(objSrc, arrItems, SelectedIndex, CBPageSelector)
{
	this.m_arrItems = arrItems;
	this.m_objSrc = objSrc;
	this.index = SelectedIndex;
	this.PageSelectCB = CBPageSelector;
	var objSelf;
	var pageName  = new Array();
	var objOld = null;
	var m_selectItemId = "1_LBL_SELECT_PAGENAME";
	var m_objSilder = null;
	
	this.Create = function()
	{
		objSelf = this;
		var selectorContent = document.createElement("DIV");
		var floatWidget = document.createElement("DIV");

		var pageNameL = new Array();
		var selectorContentWidth = 0;
		var singlePageWidth = 78;
		
		floatWidget.className = "DIV_PAGE_SILDER";
		floatWidget.id = "DIV_PAGE_SILDER"
		floatWidget.style.bottom = 0 + "px";
		m_objSilder = floatWidget;

		for(var i = 0; i < this.m_arrItems.length; ++i)
		{
			pageName[i] = document.createElement("DIV");
			pageName[i].id = i + "_LBL_SELECT_PAGENAME";
			pageName[i].className = "LBL_SELECT_PAGENAME";
			pageName[i].innerHTML = this.m_arrItems[i];
			pageName[i].style.top = 0 + "px";
			pageName[i].style.left = singlePageWidth * i + "px";
			
			AddEvent(pageName[i], "mouseover", this.CallbackButtonMouseOver);
			AddEvent(pageName[i], "mouseout", this.CallbackButtonMouseOut);
			AddEvent(pageName[i], "mousedown", this.CallbackButtonMouseDown);
			AddEvent(pageName[i], "mouseup", this.CallbackButtonMouseUp);
			AddEvent(pageName[i], "touchstart", this.CallbackBtnTouchStart);	
			AddEvent(pageName[i], "touchend", this.CallbackBtnTouchEnd);	
			AddEvent(pageName[i], "touchcancel", this.CallbackBtnTouchEnd);
			selectorContent.appendChild(pageName[i]);
		}
		
		selectorContent.appendChild(floatWidget);
		selectorContent.className = "DIV_SELECTOR_CONTENT";
		j(selectorContent).width(78 * 4);
		j(selectorContent).css({position:"absolute",
							   height:44,
							   left:(j("#DIV_FUNCTION_SELECTOR").width() - j(selectorContent).width()) / 2 + "px"
							   });
		this.m_objSrc.appendChild(selectorContent);
	
		floatWidget.style.left = 78 + "px";
		objOld = pageName[1];
		j(objOld).css({color:"rgb(255,170,0)"});
		m_selectItemId == objOld .id;
		j(this.m_objSrc).click(function(e) {
			var index = parseInt(e.target.id);
			if (objOld)
			{
				j(objOld).css({color:"rgb(230,230,230)"});
			}
			var pageNameL = parseInt(pageName[index].style.left);
			j(pageName[index]).css({color:"rgb(255,170,0)"});
			m_selectItemId = pageName[index].id;
			j(floatWidget).css({left: pageNameL + "px"});
			if (null != objSelf.PageSelectCB) {
				objSelf.PageSelectCB(objOld, pageName[index]);
				objOld = pageName[index];
			}
			
			});
	};
	
	 this.CallbackButtonMouseOver = function(objEvent)
	 {
		 var objSrc = GetEventSource(objEvent);
		if(m_selectItemId == objSrc.id)
		{
			 objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			 objSrc.style.color = "rgb(230,230,230)";
		}
		 objSrc.style.background = "transparent";
	 };
	 
	 this.CallbackButtonMouseOut = function(objEvent)
	 {
		  var objSrc = GetEventSource(objEvent);
		if(m_selectItemId == objSrc.id)
		{
			 objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			 objSrc.style.color = "rgb(230,230,230)";
		}
		 objSrc.style.background = "transparent";
	 };
	 
	this.CallbackButtonMouseDown = function(objEvent)
	{
		 var objSrc = GetEventSource(objEvent);
		
		 objSrc.style.color = "rgb(0,0,0)";
		 objSrc.style.background = "rgb(255,170,0)";	
		
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		 var objSrc = GetEventSource(objEvent);
		if(m_selectItemId == objSrc.id)
		{
			 objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			 objSrc.style.color = "rgb(230,230,230)";
		}
		 objSrc.style.background = "transparent";
	};
	this.CallbackBtnTouchStart = function(objEvent)
	{
		 var objSrc = GetEventSource(objEvent);
		 objEvent.preventDefault();
		
		 objSrc.style.color = "rgb(0,0,0)";
		 objSrc.style.background = "rgb(255,170,0)";	
	}
	this.CallbackBtnTouchEnd = function (objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if(m_selectItemId == objSrc.id)
		{
			 objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			 objSrc.style.color = "rgb(230,230,230)";
		}
		 objSrc.style.background = "transparent";
		 var index = parseInt(objEvent.target.id);
		if (objOld)
		{
			j(objOld).css({color:"rgb(230,230,230)"});
		}
		var pageNameL = parseInt(pageName[index].style.left);
		j(pageName[index]).css({ color:"rgb(255,170,0)"});
		m_selectItemId = pageName[index].id;
		j(m_objSilder).css({left: pageNameL + "px"});
		if (objSelf.PageSelectCB != null) {
			objSelf.PageSelectCB(objOld, pageName[index]);
			objOld = pageName[index];
		}
	};
	
	this.Create();
};