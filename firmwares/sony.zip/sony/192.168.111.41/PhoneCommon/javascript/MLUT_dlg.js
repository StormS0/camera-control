// JavaScript Document

function MLUTDialog(objAttachSrc, nDftSelect, funcCallback, objName)
{
	this.AttachSrc = objAttachSrc;
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	this.IsDisplay = false;
	
	var DftSelectValue = nDftSelect;
	var m_objSelf = this;
	var m_MainContainer = null;
	var m_CurrentObj = null;
	var m_ObjTitle = null;
	var m_MainContent = null;
	var m_SubLUTContent = null;
	var m_SubProfileContent = null;
	var m_SubUserThDContent = null;
	var m_YesButton = null;
	var m_BackButton = null;
	var m_CancelButton = null;
	var m_SubOKButton = null;

	var m_MainItemSelectedObj = null;				//To Record Fst-Content Item
	var m_MainSelectedType = null;					//Main Content Selected Item Index
	var m_OldSelectedType = null;					// Type: LUT , User 3D LUT, Look Profile
	var m_OldMLUTType = null;						// Selected  old Pre-Type: LUT , User 3D LUT, Look Profile
	var m_OldMLUTValue = null;						// Pre-Value (pair with m_OldMLUTType)
	var m_LUTSelectedObj = null;					//To Record SubContent of LUT Item Index 
	var m_LUTSelectedValue = null;					// Pre-Value (pair with m_LUTSelectedObj)
	var m_LookSelectedObj = null;					// To Record SubContent of Look Profile Item Index
	var m_LookSelectedValue = null;					// Pre-Value (pair with m_LookSelectedObj)
	var m_UserSelectedObj = null;					// To Record SubContent of User 3D Item Index
	var m_UserSelectedValue = null;					// Pre-Value (pair with m_UserSelectedObj)
	var b_FirstShowFlag = null;
	//Scroll Bar Flags
	var scrollStartPos = 0;
	var m_IsTouchMoving = false;
	var m_IsFirstDisplay = false;
	var arrLUTDisItems = null;
	var arrTypeDisItems = null;
	// Create Data Struction
	var arrLUTTypeItems = ["LUT", "Look Profile", "User3D LUT"];
	var arrLUTItems = ["P1:709(800%)", "P2:HG8009G40", "P3:HG8009G33", "P4:S-Log2", "P5:S-Log3","U1", "U2", "U3", "U4", "U5", "U6"];
	var arrProfileItems = ["1.LC-709", "2.LC-709typeA", "3.SLog2-709", "4.Cine+709"];
	var arrUserThDItems = ["User3D-1", "User3D-2", "User3D-3", "User3D-4"];
	var arrUserLUTMap = [["U1","User1"], ["U2","User2"], ["U3","User3"], ["U4","User4"], ["U5","User5"], ["U6","User6"]];
	var strSKeyLookProfile = "P.Menu.pmw-f5x.Video.MonitorLUT.LookProfileSelect";
	var strSKeyLUT = "P.Menu.pmw-f5x.Video.MonitorLUT.MLUTSelect";
	var strSKeyUserTD = "P.Menu.pmw-f5x.Video.MonitorLUT.User3DSelect";
	// Create Hash Map to Conver Properties
	var mLUTHashMap = new Hashtable();
	var mLUTStrFixMap = new Hashtable();
	// Create Hash Map to Save Old Selected Type And Value 
	var mOldSelectKeyMap = new Hashtable();
	
	var mlutRegx = /\w*[-%+()]*\s*\w*[-%+()]*\s*\w+[-%+()]*/gi;
	for(var i = 0; i < arrLUTItems.length; ++i)
	{
		mLUTHashMap.add(arrLUTItems[i], "LUT");					//LUT HashMap for Mode
	}
	for(var k = 0 ; k < arrProfileItems.length; ++k)
	{
		mLUTHashMap.add(arrProfileItems[k], "Look Profile");	//Look Profile HashMap for Mode 
	}
	for(var p = 0; p <arrUserThDItems.length; ++p)
	{
		mLUTHashMap.add(arrUserThDItems[p], "User3D LUT");		//User 3D HashMap for Mode 
	}
	//for Find Mlut value
	for(var m = 0; m < arrLUTItems.length;++m)
	{
		var mlutString = arrLUTItems[m].match(mlutRegx);
		if(!mlutString[1]) 
		{
			mLUTStrFixMap.add(mlutString[0], arrLUTItems[m]);	// LUT U1~U6 for Mode 
		}
		else
		{
			mLUTStrFixMap.add(mlutString[1], arrLUTItems[m]);	//LUT HashMap for Mode 
		}
	}
	//for Find Look File value
	for(var n = 0; n < arrProfileItems.length; ++n)
	{
		var ulutString = arrProfileItems[n].match(mlutRegx);
		mLUTStrFixMap.add(ulutString[1], arrProfileItems[n]);		
	}

	this.SetUlutMap = function(value)
	{
		for(i =0; i<arrUserLUTMap.length; ++i)
		{
			if(value == arrUserLUTMap[i][1])
			{
				return arrUserLUTMap[i][0];
			}
		}
	}

	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		var divContainer = document.createElement("DIV");
		var divTitle = document.createElement("DIV");
		var divTopSeparator = document.createElement("DIV");
		var divBottomSeparator = document.createElement("DIV");
		var divArrow = document.createElement("DIV");
		
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divArrow.className = "DIV_DLG_RIGHT_ARROW";
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.top = "-1px";
		divBottomSeparator.style.top = "265px";
		divMainContainer.style.display = "none";
		divMainContainer.appendChild(divTitle);
		divMainContainer.appendChild(divArrow);
		divMainContainer.appendChild(divContainer);
		
		divMainContainer.className = "DIV_DLG_MAIN";
		divContainer.className = "DIV_DLG_SUB";
		m_MainContainer = divMainContainer;
		
		//Title Container start
		divTitle.className = "DIV_DLG_TITLE";
		m_ObjTitle = divTitle;
		//Create Fst Content
		var divMainContent = document.createElement("DIV");
		divMainContent.className = "DIV_DLG_ITEMAREA";
		m_MainContent = divMainContent;
		
		for (var i = 0; i < arrLUTTypeItems.length; i++)
		{
			var divMainItem = document.createElement("DIV");
			var divMlutArrow = document.createElement("DIV");
			divMainItem.className = "DIV_DLG_ITEM";
			divMainItem.style.top = (i * 44) + "px";
			divMainItem.innerHTML = arrLUTTypeItems[i];
			divMainItem.id = i + "_" + this.NameID + "_DLG_MAIN_ITEM";
			if (m_MainSelectedType == arrLUTTypeItems[i]) {
				divMainItem.style.color = "rgb(255,170,0)";
			}
			if (i % 2 == 0) {
				j(divMainItem).css("background-color","rgb(28,28,28)");
			}
			
			var divMainItemIcon = document.createElement("DIV");
			divMainItemIcon.className = "DIV_DLG_ITEM_ICON";
			divMainItemIcon.style.backgroundImage = "";
			divMainItemIcon.id = i + "_MLUT_TYPEITEM_ICON";

			divMainItem.appendChild(divMainItemIcon);
			divMlutArrow.className = "DIV_DLG_ARROW";
			divMlutArrow.innerHTML = ">";
			divMlutArrow.id = i + "_MLUT_ARROW";
			divMainItem.appendChild(divMlutArrow);

			if (m_MainSelectedType == arrLUTTypeItems[i])
			{
				divMainItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divMainItemIcon.style.backgroundRepeat = "no-repeat";
				divMainItem.style.color = "rgb(255, 170, 0)";
			}

			AddEvent(divMainItem, "click", this.CallbackMainItemClick);
			AddEvent(divMainItem, "mouseout", this.CallbackMainItemMouseOut);
			AddEvent(divMainItem, "mousedown", this.CallbackMainItemMouseDown);
			AddEvent(divMainItem, "mouseup", this.CallbackMainItemMouseUp);
			AddEvent(divMainItem, "touchstart", this.CallbackMainItemTouchStart);	
			AddEvent(divMainItem, "touchend", this.CallbackMainItemTouchEnd);
			AddEvent(divMainItem, "touchcancel", this.CallbackMainItemTouchEnd);

			divMainContent.appendChild(divMainItem);
			m_MainItemSelectedObj = divMainItem;
		}
		
		var divMainItem = document.createElement("DIV");
		divMainItem.className = "DIV_DLG_ITEM";
		divMainItem.style.top = (2 * 44) + "px";
		divMainItem.style.display = "none";
		divMainItem.id = 6 + "_" + this.NameID + "_DLG_MAIN_ITEM";
		j(divMainItem).css("background-color","rgb(28,28,28)");
		divMainContent.appendChild(divMainItem);
		
		this.FillItemAreaBg(divMainContent, arrLUTTypeItems.length);
		//	Sub Select for LUT 
		this.CreateSubContent(divContainer, "LUT", arrLUTItems, this.CallbackItemLUTItemClick, m_LUTSelectedObj);
		//SubSelect Area for Look Profile
		this.CreateSubContent(divContainer, "Look Profile", arrProfileItems, this.CallbackLookProfileItemClick, m_LookSelectedObj);
		//SubSelect Area for User3D LUT
		this.CreateSubContent(divContainer, "User3D LUT", arrUserThDItems, this.CallbackUserThDItemClick, m_UserSelectedObj);

		var divYesButton = document.createElement("DIV");
		divYesButton.className = "DIV_DLG_BUTTON";
		divYesButton.style.left = 158 + "px";
		divYesButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divYesButton.style.top = 266 + "px";
		m_YesButton = divYesButton;
		
		var divBackButton = document.createElement("DIV");
		divBackButton.className = "DIV_DLG_BACK_BTN";
		divBackButton.style.display = "none";
		divBackButton.style.zIndex = 2;
		divBackButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divBackButton.style.top = 266 + "px";
		divBackButton.style.left = -4 + "px";
		m_BackButton = divBackButton;
		
		var divNoButton = document.createElement("DIV");
		divNoButton.className = "DIV_DLG_BUTTON";
		divNoButton.style.left = -4 + "px";
		divNoButton.id = "2_DIV_" + this.NameID + "_DLG_BTN";
		divNoButton.style.top = 266 + "px";
		m_CancelButton = divNoButton;
		
		var divSubOKButton = document.createElement("DIV");
		divSubOKButton.className = "DIV_DLG_BUTTON";
		divSubOKButton.style.zIndex = 2;
		divSubOKButton.style.left = 158 + "px";
		divSubOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divSubOKButton.style.top = 266 + "px";	
		m_SubOKButton = divSubOKButton;
		
		//Add Events to Main page Button
		this.AddBtnEvents(divYesButton, "OK");
		this.AddBtnEvents(divNoButton, "Cancel");
		//Add Event To Sub Page Button
		this.AddBtnEvents(divBackButton, "Back");
		this.AddBtnEvents(divSubOKButton, "OK");
		
		divContainer.appendChild(divTopSeparator);
		divContainer.appendChild(divMainContent);
		divContainer.appendChild(divBottomSeparator);
		divContainer.appendChild(divYesButton);
		divContainer.appendChild(divNoButton);
		divContainer.appendChild(divBackButton);
		divContainer.appendChild(divSubOKButton);	
		
		//GetParent(this.AttachSrc).appendChild(divMainContainer);
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);
		
		/*divMainContainer.style.left = parseInt(this.AttachSrc.style.left) - 32 + "px";
		divMainContainer.style.top = parseInt(this.AttachSrc.style.top) - 390 + "px";*/
		//divMainContainer.style.left = parseInt(this.AttachSrc.style.left) - 298 + "px";
		//divMainContainer.style.top = parseInt(this.AttachSrc.style.top) -186 + "px";
	};

	this.FillItemAreaBg = function(objMainContent, arrItemsLength)
	{
		if (arrItemsLength < 6)
		{
			for (var i = arrItemsLength; i < 6; ++i)
			{
				var divMainItem = document.createElement("DIV");
				divMainItem.className = "DIV_DLG_ITEM";
				divMainItem.style.top = (i * 44) + "px";
				if (i % 2 == 0) {
					j(divMainItem).css("background-color","rgb(28,28,28)");
				}
				objMainContent.appendChild(divMainItem);
			}
		}
	};

	this.CreateSubContent = function(divContainer, strType, arrItemList, CallBackItemClickFun, mObjSelectItem)
	{
		var divSubContent = document.createElement("DIV");
		divSubContent.className = "DIV_DLG_ITEMAREA";
		divSubContent.style.display = "none";
		switch(strType)
		{
			case "LUT":
			m_SubLUTContent = divSubContent;
			break;
			case "Look Profile":
			m_SubProfileContent = divSubContent;
			break;
			case "User3D LUT":
			m_SubUserThDContent = divSubContent;
			break;
			default:
			break;
		}
		if (arrItemList.length > 6) {
			divSubContent.style.overflowY = "scroll";
		} else {
			divSubContent.style.overflowY = "hidden";
		}
		AddEvent(divSubContent, "touchstart", m_objSelf.CallbackItemAreaTouchStart);
		AddEvent(divSubContent, "touchmove", m_objSelf.CallbackItemAreaTouchMove);
		AddEvent(divSubContent, "touchend", CallBackItemClickFun);
		for (var i = 0; i < arrItemList.length; i++)
		{
			var divSubItem = document.createElement("DIV");
			divSubItem.className = "DIV_DLG_ITEM";
			divSubItem.style.top = (i * 44) + "px";
			divSubItem.innerHTML = arrItemList[i];
			if (i % 2 == 0) {
				j(divSubItem).css("background-color","rgb(28,28,28)");
			}
			switch(strType)
			{
				case "LUT":
				divSubItem.id = i + "_" + this.NameID + "_DLG_LUTSUB_ITEM";
				break;
				case "Look Profile":
				divSubItem.id = i + "_" + this.NameID + "_DLG_LP_SUB_ITEM";
				break;
				case "User3D LUT":
				divSubItem.id = i + "_" + this.NameID + "_DLG_UTDSUB_ITEM";
				break;
				default:
				break;
			}

			AddEvent(divSubItem, "click", CallBackItemClickFun);
			AddEvent(divSubItem, "mousedown", m_objSelf.CallbackSubItemMouseDown);
			AddEvent(divSubItem, "mouseup", m_objSelf.CallbackSubItemMouseUp);
			AddEvent(divSubItem, "mouseout", m_objSelf.CallbackSubItemMouseOut);
			AddEvent(divSubItem, "touchstart", m_objSelf.CallbackSubItemTouchStart);	
			AddEvent(divSubItem, "touchend", m_objSelf.CallbackSubItemTouchEnd);
			AddEvent(divSubItem, "touchcancel", m_objSelf.CallbackSubItemTouchEnd);
			
			var divSubItemIcon = document.createElement("DIV");
			divSubItemIcon.className = "DIV_DLG_ITEM_ICON";
			divSubItemIcon.style.backgroundImage = "";
			divSubItemIcon.id = i + "_" + this.NameID + "_ICON";
			
			divSubItem.appendChild(divSubItemIcon);
			divSubContent.appendChild(divSubItem);
			mObjSelectItem = divSubItem;
		}
		divContainer.appendChild(divSubContent);
		m_objSelf.FillItemAreaBg(divSubContent, arrItemList.length);
	};
	
	this.AddBtnEvents = function(objButton, strText)
	{
		AddEvent(objButton, "click", this.CallbackButtonClick);
		AddEvent(objButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(objButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(objButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(objButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(objButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(objButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(objButton, "touchcancel", this.CallbackBtnTouchCancel);
		objButton.innerHTML = strText;
	}
	
	this.CallbackItemAreaTouchStart = function(objEvent)
	{
		scrollStartPos = this.scrollTop + objEvent.touches[0].pageY;//get first touchDown position.
		objEvent.preventDefault();
		m_IsTouchMoving = false; 
	}; 
	
	this.CallbackItemAreaTouchMove = function(objEvent)
	{
		//change current touchdown item's scrollTop in 
		this.scrollTop = scrollStartPos - objEvent.touches[0].pageY;
		objEvent.preventDefault();
		m_IsTouchMoving = true;
	};
	
	this.CallbackItemAreaTouchEnd = function (objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;			//if not, it will select nothing when scroll the scrollbar.
		}
		
		var b_isDisItem = m_objSelf.CheckClickItemIsDisabled(objSrc.id);
		if (b_isDisItem)
		{
			return;
		}		
		
		if (m_SelectedObj)
		{
			m_SelectedObj.children[0].style.backgroundImage = "";
			m_SelectedObj.style.color = "rgb(230, 230, 230)";
		}

		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_SelectedObj = objSrc;
			m_SelectedValue = objSrc.textContent;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_SelectedObj = GetParent(objSrc);
		}
		
		if (null != m_objSelf.CallbackFunc)
		{
			if ("LUT" == m_MainSelectedType)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.MLUTSelect", mlutItems[parseInt(m_SelectedObj.id)]);
			}
		}
	};
	
	this.ShowDialog = function()
	{
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_MainContainer.style.display = "none";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "none";
			m_SubOKButton.style.display = "none";
			m_IsFirstDisplay = false;
			m_objSelf.SetOKButton();
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			return;
		}
		
		if (m_MainContainer.style.display == "block")
		{
			m_MainContainer.style.display = "none";
			this.IsDisplay = false;
			m_IsFirstDisplay = false;
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else
		{
			m_IsFirstDisplay = true;
			m_MainContainer.style.display = "block";
			m_SubLUTContent.style.display = "none";
			m_SubProfileContent.style.display = "none";
			m_SubUserThDContent.style.display = "none";
			m_MainContent.style.display = "block";
			m_YesButton.style.display = "block";
			m_CancelButton.style.display = "block";
			b_FirstShowFlag = true;
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
			
			var SettingValue = m_objSelf.SetUlutMap($("TEXT_MLUT").innerHTML);
			if (!SettingValue) {
				SettingValue = mLUTStrFixMap.items($("TEXT_MLUT").innerHTML);
			}
			if(!SettingValue) {
				SettingValue = $("TEXT_MLUT").innerHTML;
			}			
			mMode = mLUTHashMap.items(SettingValue);
			m_objSelf.SetCurrentModeAndValue(mMode, SettingValue);

			var index = j.inArray(m_MainSelectedType,arrLUTTypeItems);
			for (var i = 0; i < arrLUTTypeItems.length; ++i)
			{
				m_MainContent.children[i].style.color = "rgb(230,230,230)";
				m_MainContent.children[i].children[0].style.backgroundImage = "";
				if (index == i)
				{
					m_MainContent.children[i].style.color = "rgb(255,170,0)";
					m_MainContent.children[i].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				}
			}
			this.IsDisplay = true;
			if (m_IsFirstDisplay)
			{
				m_IsFirstDisplay = false;
			}	
		}
		m_BackButton.style.display = "none";
		m_SubOKButton.style.display = "none";
	}

	this.SetCurrentModeAndValue = function(Mode, Value)
	{
		m_OldMLUTType = Mode;
		m_OldMLUTValue = Value;
		m_objSelf.SetCurrentMLUTType(Mode);
		m_objSelf.SetSelect(Mode, Value);
	}

	this.SetCurrentMLUTType = function(Mode)
	{
		var selectedIndex = j.inArray(Mode, arrLUTTypeItems);			//return Index in Array
		m_MainItemSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_MAIN_ITEM");
		m_MainSelectedType = Mode;
		for(var i = 0; i < 2; i++){
			$(i + "_" + this.NameID + "_DLG_MAIN_ITEM").style.color = "rgb(230,230,230)";
			$(i + "_" + this.NameID + "_DLG_MAIN_ITEM").children[0].style.backgroundImage = "";
		}
		
		m_MainItemSelectedObj.style.color = "rgb(255,170,0)";
		m_MainItemSelectedObj.children[0].style.backgroundImage =  "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";		
	}

	this.CallbackItemAreaTouchStart = function(objEvent)
	{
		scrollStartPos = this.scrollTop + objEvent.touches[0].pageY;		//get first touchDown position.
		objEvent.preventDefault();
		m_IsTouchMoving = false; 
	}; 

	this.CallbackItemAreaTouchMove = function(objEvent)
	{
		//change current touchdown item's scrollTop in 
		this.scrollTop = scrollStartPos - objEvent.touches[0].pageY;
		objEvent.preventDefault();
		m_IsTouchMoving = true;
	};

	this.CheckClickItemIsDisabled = function (id)
	{
		if (!arrLUTDisItems)
		{
			return false;
		}
		var Index = parseInt(id);
		for (var i = 0; i < arrLUTDisItems.length; i++)
		{
			if (arrLUTDisItems[i] == Index)
			{
				return true;
			}
		}
		return false;
	};
	
	this.CheckTypeItemIsDisabled = function (id)
	{
		if (!arrTypeDisItems)
		{
			return false;
		}
		var Index = parseInt(id);
		for (var i = 0; i < arrTypeDisItems.length; i++)
		{
			if (arrTypeDisItems[i] == Index)
			{
				return true;
			}
		}
		return false;
	};
	
	this.CallbackMainItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") || 
			(objSrc.id == "1_MLUT_ARROW") ||(objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		
		if (j(objSrc).text().replace(">","") == m_MainSelectedType)//selected Type
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackMainItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") ||
			 (objSrc.id == "1_MLUT_ARROW") ||(objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};

	this.CallbackMainItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") ||
			 (objSrc.id == "1_MLUT_ARROW") || (objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		
		if (j(objSrc).text().replace(">","") == m_MainSelectedType)//selected Type
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}	
	};
	
	this.CallbackMainItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") || 
			(objSrc.id == "1_MLUT_ARROW") || (objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackMainItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (objSrc.style.opacity === 0.2)
		{
			return;
		}
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") || 
			(objSrc.id == "1_MLUT_ARROW") || (objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}

		if (j(objSrc).text().replace(">","") == m_MainSelectedType)		//selected Type
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}

		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		objSrc.style.color = "rgb(255, 170, 0)";
		m_OldSelectedType = j(objSrc).text().replace(">","");

		var iItemNum = parseInt(objSrc.id);
		if (0 == iItemNum)    //LUT 
		{
			m_MainContent.style.display = "none";
			m_SubLUTContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";
			m_MainSelectedType = "LUT";
			if (null != m_objSelf.CallbackFunc) {
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.MLUTSelect", ""/*m_LUTSelectedValue*/);
			}
			var m_top = parseInt(m_LUTSelectedObj.style.top);
			j(m_SubLUTContent).animate({scrollTop: m_top}, 0);			
		}
		else if (1 == iItemNum)		//Look Profile
		{
			m_MainContent.style.display = "none";
			m_SubProfileContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";	
			m_MainSelectedType = "Look Profile";			
			if (null != m_objSelf.CallbackFunc)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.LookProfileSelect", ""/*m_LookSelectedValue*/);
			}			
		}
		else if(2 == iItemNum)			//3D LUT
		{
			m_MainContent.style.display = "none";
			m_SubUserThDContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";	
			m_MainSelectedType = "User3D LUT";			
			if (null != m_objSelf.CallbackFunc)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.User3DSelect", ""/*m_UserSelectedValue*/);
			}		
		}
		this.IsDisplay = true;
		MLUTCtrl.GetCapabilities();
	};

	this.CallbackMainItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if (!objSrc.hasChildNodes() || (objSrc.id == "0_MLUT_ARROW") || 
			(objSrc.id == "1_MLUT_ARROW") || (objSrc.id == "2_MLUT_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		if (objSrc.style.opacity === 0.2)
		{
			return;
		}
		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		objSrc.style.color = "rgb(255, 170, 0)";
		m_OldSelectedType = j(objSrc).text().replace(">","");

		var iItemNum = parseInt(objSrc.id);
		if (0 == iItemNum)    //LUT 
		{
			m_MainContent.style.display = "none";
			m_SubLUTContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";
			m_MainSelectedType = "LUT";
			if (null != m_objSelf.CallbackFunc) {
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.MLUTSelect", ""/*m_LUTSelectedValue*/);
			}
			var m_top = parseInt(m_LUTSelectedObj.style.top);
			j(m_SubLUTContent).animate({scrollTop: m_top}, 0);			
		}
		else if (1 == iItemNum)		//Look Profile
		{
			m_MainContent.style.display = "none";
			m_SubProfileContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";	
			m_MainSelectedType = "Look Profile";			
			if (null != m_objSelf.CallbackFunc)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.LookProfileSelect", ""/*m_LookSelectedValue*/);
			}			
		}
		else if(2 == iItemNum)			//3D LUT
		{
			m_MainContent.style.display = "none";
			m_SubUserThDContent.style.display = "block";
			m_YesButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "block";
			m_SubOKButton.style.display = "block";	
			m_MainSelectedType = "User3D LUT";			
			if (null != m_objSelf.CallbackFunc)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.User3DSelect", ""/*m_UserSelectedValue*/);
			}		
		}
		this.IsDisplay = true;
		MLUTCtrl.GetCapabilities();
	}
	

	this.CallbackSubItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if ((objSrc == m_LUTSelectedObj) || (objSrc == m_LookSelectedObj) || (objSrc == m_UserSelectedObj)) {
			objSrc.style.color = "rgb(255,170,0)";
		} else {
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackSubItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};

	this.CallbackSubItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_CurrentObj)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}		
	};
	
	this.CallbackSubItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackSubItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}

		if ((objSrc == m_LUTSelectedObj) || (objSrc == m_LookSelectedObj) ||(objSrc == m_UserSelectedObj)) {
			objSrc.style.color = "rgb(255,170,0)";
		} else {
			objSrc.style.color = "rgb(230,230,230)";
		}

		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}	
	};
	
	//LUT Sub Content Item Click CB
	this.CallbackItemLUTItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;			//if not, it will select nothing when scroll the scrollbar.
		}

		var b_isDisItem = m_objSelf.CheckClickItemIsDisabled(objSrc.id);
		if (b_isDisItem)
		{
			return;
		}		
		
		if (m_LUTSelectedObj)
		{
			m_LUTSelectedObj.children[0].style.backgroundImage = "";
			m_LUTSelectedObj.style.color = "rgb(230, 230, 230)";
		}

		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_LUTSelectedObj = objSrc;
			m_LUTSelectedValue = objSrc.textContent;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_LUTSelectedObj = GetParent(objSrc);
		}
		
		if (null != m_objSelf.CallbackFunc)
		{
			if ("LUT" == m_MainSelectedType)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.MLUTSelect", arrLUTItems[parseInt(m_LUTSelectedObj.id)]);
			}
		}
	};
	//Look Profile Sub Content Item Click CB
	this.CallbackLookProfileItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;			//if not, it will select nothing when scroll the scrollbar.
		}
		if (m_LookSelectedObj)
		{
			m_LookSelectedObj.children[0].style.backgroundImage = "";
			m_LookSelectedObj.style.color = "rgb(230, 230, 230)";
		}

		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_LookSelectedObj = objSrc;
			m_LookSelectedValue = objSrc.textContent;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_LookSelectedObj = GetParent(objSrc);
		}
		
		if (null != m_objSelf.CallbackFunc)
		{
			if ("Look Profile" == m_MainSelectedType)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.LookProfileSelect", arrProfileItems[parseInt(m_LookSelectedObj.id)]);
			}
		}
	}
	//User3D LUT Sub Content Item Click CB
	this.CallbackUserThDItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ((objSrc.id == "") || (m_IsTouchMoving == true))
		{
			return;			//if not, it will select nothing when scroll the scrollbar.
		}
		if (m_UserSelectedObj)
		{
			m_UserSelectedObj.children[0].style.backgroundImage = "";
			m_UserSelectedObj.style.color = "rgb(230, 230, 230)";
		}

		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_UserSelectedObj = objSrc;
			m_UserSelectedValue = objSrc.textContent;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_UserSelectedObj = GetParent(objSrc);
		}
		
		if (null != m_objSelf.CallbackFunc)
		{
			if ("User3D LUT" == m_MainSelectedType)
			{
				m_objSelf.CallbackFunc("P.Menu.pmw-f5x.Video.MonitorLUT.User3DSelect", arrUserThDItems[parseInt(m_UserSelectedObj.id)]);
			}
		}
	}
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";		
	};

	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";		
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
	};

	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage  = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};

	this.SetOKButton = function()
	{
			if ("LUT" == m_MainSelectedType)
			{
				m_objSelf.setOldValueForCancel("LUT", m_LUTSelectedValue);
				m_objSelf.setOldValueForCancel("User3D LUT", m_UserSelectedValue);
				m_objSelf.setSubValueForCancel();
			}else if ("Look Profile" == m_MainSelectedType)
			{
				m_objSelf.setOldValueForCancel("Look Profile", m_LookSelectedValue);
				m_objSelf.setOldValueForCancel("User3D LUT", m_UserSelectedValue);
				m_objSelf.setSubValueForCancel();
			}
			else if("User3D LUT" == m_MainSelectedType)
			{
				m_objSelf.setOldValueForCancel("Look Profile", m_LookSelectedValue);
				m_objSelf.setOldValueForCancel("LUT", m_LUTSelectedValue);
				m_objSelf.setSubValueForCancel();
			}
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		m_YesButton.style.display = "block";
		m_BackButton.style.display = "none";
		m_SubOKButton.style.display = "none";
		var iButtonNum = parseInt(objSrc.id);
		if (1 == iButtonNum)				//OK Button
		{
			m_MainContainer.style.display = "none";
			m_IsFirstDisplay = false;
			m_objSelf.SetOKButton();
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		} 
		else if (0 == iButtonNum)			//Back Button
		{
			m_SubLUTContent.style.display = "none";
			m_SubProfileContent.style.display = "none";
			m_SubUserThDContent.style.display = "none";
			m_MainContent.style.display = "block";
			m_CancelButton.style.display = "block";
			m_BackButton.style.display = "none";
			m_SubOKButton.style.display = "none";

			var index = j.inArray(m_MainSelectedType, arrLUTTypeItems);
			for (var i = 0; i < arrLUTTypeItems.length; ++i)
			{
				m_MainContent.children[i].style.color = "rgb(230,230,230)";
				m_MainContent.children[i].children[0].style.backgroundImage = "";
				if (index == i)
				{
					m_MainContent.children[i].style.color = "rgb(255,170,0)";
					m_MainContent.children[i].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				}
			}
		}
		else if (2 == iButtonNum)			//Cancel Button
		{
			m_MainContainer.style.display = "none";
			m_IsFirstDisplay = false;
			if (null != m_objSelf.CallbackFunc)
			{
				switch(m_OldMLUTType)
				{
					case "LUT":
					if(0 != mOldSelectKeyMap.count()) {
						m_objSelf.ResetOtherModeAndValue("Look Profile", strSKeyLookProfile, "User3D LUT", strSKeyUserTD);
					}
					m_objSelf.CallbackFunc(strSKeyLUT, m_OldMLUTValue);
					m_LUTSelectedValue = m_OldMLUTValue;
					break;
					case "Look Profile":
					if(0 != mOldSelectKeyMap.count()) {
						m_objSelf.ResetOtherModeAndValue("LUT", strSKeyLUT, "User3D LUT", strSKeyUserTD);
					}
					m_objSelf.CallbackFunc(strSKeyLookProfile, m_OldMLUTValue);
					m_LookSelectedValue = m_OldMLUTValue;
					break;
					case "User3D LUT":
					if(0 != mOldSelectKeyMap.count()) {
						m_objSelf.ResetOtherModeAndValue("LUT", strSKeyLUT, "Look Profile", strSKeyLookProfile);
					}
					m_objSelf.CallbackFunc(strSKeyUserTD, m_OldMLUTValue);
					m_UserSelectedValue = m_OldMLUTValue;
					break;
					default:
					break;
				}
				m_MainSelectedType = m_OldMLUTType;
				m_OldSelectedType = m_OldMLUTType;
				m_objSelf.SetSelect(m_OldMLUTType, m_OldMLUTValue);
			} else {
				//Error
			}
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		m_objSelf.CallbackFunc("", "",parseInt(objSrc.id));
	};

	this.ResetOtherModeAndValue = function(strValueA, strOtherKeyValueA, strValueB, strOtherKeyValueB)
	{
		m_objSelf.CallbackFunc(strOtherKeyValueA, mOldSelectKeyMap.items(strOtherKeyValueA));
		m_objSelf.CallbackFunc(strOtherKeyValueB, mOldSelectKeyMap.items(strOtherKeyValueB));
		m_objSelf.SetSelect(strValueA, mOldSelectKeyMap.items(strOtherKeyValueA));
		m_objSelf.SetSelect(strValueB, mOldSelectKeyMap.items(strOtherKeyValueB));
	}
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		objEvent.preventDefault();
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";		
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";
		}
		objSrc.style.color = "rgb(0,0,0)";
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
		
		m_objSelf.CallbackButtonClick(objEvent);
	};
	
	this.CallbackBtnTouchCancel = function(objEvent)
	{

		var objSrc = GetEventSource(objEvent);
		
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
	};
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";		
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";
		}
		objSrc.style.color = "rgb(0,0,0)";
	};

	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";		
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
	};
	
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.SetSelect = function(categoryValue, selectedValue)
	{
		if ("LUT" == categoryValue)
		{
			var selectedIndex = j.inArray(selectedValue, arrLUTItems);				//Return index in array
			m_LUTSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_LUTSUB_ITEM");
			m_LUTSelectedValue = selectedValue;
			for(var i = 0; i < 10; i++) 
			{
				$(i + "_" + this.NameID + "_DLG_LUTSUB_ITEM").style.color = "rgb(230,230,230)";
				$(i + "_" + this.NameID + "_DLG_LUTSUB_ITEM").children[0].style.backgroundImage = "";
			}
			
			m_LUTSelectedObj.style.color = "rgb(255,170,0)";
			m_LUTSelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			
		}
		else if ("Look Profile" == categoryValue)
		{
			selectedIndex = j.inArray(selectedValue, arrProfileItems);					//return index in array
			m_LookSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_LP_SUB_ITEM");
			m_LookSelectedValue = selectedValue;
			
			for(var i = 0; i < 4; i++){
				$(i + "_" + this.NameID + "_DLG_LP_SUB_ITEM").style.color = "rgb(230,230,230)";
				$(i + "_" + this.NameID + "_DLG_LP_SUB_ITEM").children[0].style.backgroundImage = "";
			}
			
			m_LookSelectedObj.style.color = "rgb(255,170,0)";
			m_LookSelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";			
		} 
		else if("User3D LUT" == categoryValue) 
		{
			selectedIndex = j.inArray(selectedValue, arrUserThDItems);					//return index in array
			m_UserSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_UTDSUB_ITEM");
			m_UserSelectedValue = selectedValue;
			
			for(var i = 0; i < 4; i++){
				$(i + "_" + this.NameID + "_DLG_UTDSUB_ITEM").style.color = "rgb(230,230,230)";
				$(i + "_" + this.NameID + "_DLG_UTDSUB_ITEM").children[0].style.backgroundImage = "";
			}

			m_UserSelectedObj.style.color = "rgb(255,170,0)";
			m_UserSelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		}
		else
		{
			//Mode Error
		}
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDialogShow = true;
		if(m_MainContainer.style.display == "none")
		{
			b_IsDialogShow= false;
		}
		return b_IsDialogShow;
	}

	this.SetMlutType = function(selectedType)
	{
		m_OldSelectedType = selectedType;
		m_MainSelectedType = selectedType;		
	}
	
	this.setMLUTSelect = function(categoryValue, selectedValue)
	{		
			var selectedIndex = j.inArray(selectedValue, arrLUTItems);			//return index in array
			m_LUTSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_LUTSUB_ITEM");
			m_LUTSelectedValue = selectedValue;
			mOldSelectKeyMap.add(strSKeyLUT, selectedValue);
			for(var i = 0; i < 11; i++){
				$(i + "_" + this.NameID + "_DLG_LUTSUB_ITEM").style.color = "rgb(230,230,230)";
				$(i + "_" + this.NameID + "_DLG_LUTSUB_ITEM").children[0].style.backgroundImage = "";
			}
			
			m_LUTSelectedObj.style.color = "rgb(255,170,0)";
			m_LUTSelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";		
	}
	
	this.setLookProfileSelect = function(categoryValue, selectedValue)
	{
			selectedIndex = j.inArray(selectedValue, arrProfileItems);//return index in array
			m_LookSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_LP_SUB_ITEM");
			m_LookSelectedValue = selectedValue;
			mOldSelectKeyMap.add(strSKeyLookProfile, selectedValue);
			for(var i = 0; i < 4; i++){
				$(i + "_" + this.NameID + "_DLG_LP_SUB_ITEM").style.color = "rgb(230,230,230)";
				$(i + "_" + this.NameID + "_DLG_LP_SUB_ITEM").children[0].style.backgroundImage = "";
			}
			m_LookSelectedObj.style.color = "rgb(255,170,0)";
			m_LookSelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";	
			
	}

	this.SetUserThDSelect = function(categoryValue, selectedValue)
	{
		selectedIndex = j.inArray(selectedValue, arrUserThDItems);		//return index in array
		m_UserSelectedObj = $(selectedIndex + "_" + this.NameID + "_DLG_UTDSUB_ITEM");
		m_UserSelectedValue = selectedValue;
		mOldSelectKeyMap.add(strSKeyUserTD, selectedValue);
		for(var i = 0; i < 4; i++) {
			$(i + "_" + this.NameID + "_DLG_UTDSUB_ITEM").style.color = "rgb(230,230,230)";
			$(i + "_" + this.NameID + "_DLG_UTDSUB_ITEM").children[0].style.backgroundImage = "";
		}

		m_UserSelectedObj.style.color = "rgb(255,170,0)";
		m_UserSelectedObj.children[0].style.backgroundImage ="URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";	
	}

	this.setSubValueForCancel = function()
	{
		mOldSelectKeyMap.clear()
	}
	
	this.setOldValueForCancel = function(categoryValue, selectedValue)
	{
		 m_OldMLUTType = categoryValue;
		 m_OldMLUTValue = selectedValue;
	}
	
	this.SetCateListItemsDisable = function(NameID, arrDisIndex, isDisabled)
	{
		if (isDisabled)
		{
			arrTypeDisItems = arrDisIndex;
		}
		for (var i = 0; i < arrDisIndex.length; i++) 
		{
			if (isDisabled == true)
			{
				var DisabledItem = $(arrDisIndex[i] + "_" + NameID + "_DLG_MAIN_ITEM");
				RemoveEvent(DisabledItem, "click", this.CallbackMainItemClick);
				RemoveEvent(DisabledItem, "mouseout", this.CallbackMainItemMouseOut);
				RemoveEvent(DisabledItem, "mousedown", this.CallbackMainItemMouseDown);
				RemoveEvent(DisabledItem, "mouseup", this.CallbackMainItemMouseUp);
				RemoveEvent(DisabledItem, "touchstart", this.CallbackMainItemTouchStart);
				RemoveEvent(DisabledItem, "touchend", this.CallbackMainItemTouchEnd);
				RemoveEvent(DisabledItem, "touchcancel", this.CallbackMainItemTouchEnd);
				DisabledItem.style.opacity = 0.2;
			}
			else
			{
				var DisabledItem = $(arrDisIndex[i] + "_" + NameID + "_DLG_MAIN_ITEM");
				AddEvent(DisabledItem, "click", this.CallbackMainItemClick);
				AddEvent(DisabledItem, "mouseout", this.CallbackMainItemMouseOut);
				AddEvent(DisabledItem, "mousedown", this.CallbackMainItemMouseDown);
				AddEvent(DisabledItem, "mouseup", this.CallbackMainItemMouseUp);
				AddEvent(DisabledItem, "touchstart", this.CallbackMainItemTouchStart);
				AddEvent(DisabledItem, "touchend", this.CallbackMainItemTouchEnd);
				AddEvent(DisabledItem, "touchcancel", this.CallbackMainItemTouchEnd);
				DisabledItem.style.opacity = 1;
			}
		}
	};
	
	this.SetLUTListItemsDisable = function(NameID, arrDisIndex, isDisabled)
	{
		if (isDisabled)
		{
			arrLUTDisItems = arrDisIndex;
		}
		for (var i = 0; i < arrDisIndex.length; i++) 
		{
			if (isDisabled == true)
			{
				var DisabledItem = $(arrDisIndex[i] + "_" + NameID + "_DLG_LUTSUB_ITEM");
				RemoveEvent(DisabledItem, "click", this.CallbackItemLUTItemClick);
				RemoveEvent(DisabledItem, "mousedown", this.CallbackSubItemMouseDown);
				RemoveEvent(DisabledItem, "mouseup", this.CallbackSubItemMouseUp);
				RemoveEvent(DisabledItem, "mouseout", this.CallbackSubItemMouseOut);
				RemoveEvent(DisabledItem, "touchstart", this.CallbackSubItemTouchStart);	
				RemoveEvent(DisabledItem, "touchend", this.CallbackSubItemTouchEnd);
				RemoveEvent(DisabledItem, "touchcancel", this.CallbackSubItemTouchEnd);
				DisabledItem.style.opacity = 0.2;
			}
			else
			{
				var DisabledItem = $(arrDisIndex[i] + "_" + NameID + "_DLG_LUTSUB_ITEM");
				AddEvent(DisabledItem, "click", this.CallbackItemLUTItemClick);
				AddEvent(DisabledItem, "mousedown", this.CallbackSubItemMouseDown);
				AddEvent(DisabledItem, "mouseup", this.CallbackSubItemMouseUp);
				AddEvent(DisabledItem, "mouseout", this.CallbackSubItemMouseOut);
				AddEvent(DisabledItem, "touchstart", this.CallbackSubItemTouchStart);	
				AddEvent(DisabledItem, "touchend", this.CallbackSubItemTouchEnd);
				AddEvent(DisabledItem, "touchcancel", this.CallbackSubItemTouchEnd);
				DisabledItem.style.opacity = 1;
			}
		}
	};
	
	this.SetLUTListItems = function(arrItems)
	{
		if (arrLUTItems == arrItems)
		{
			return;
		}
		m_objSelf.DeleteOldDlgItemsDIV();
		arrLUTItems = arrItems;
		
		for (var i = 0; i < arrLUTItems.length; i++)
		{
			var divSubItem = document.createElement("DIV");
			divSubItem.className = "DIV_DLG_ITEM";
			divSubItem.id = i + "_" + m_objSelf.NameID + "_DLG_LUTSUB_ITEM";
			divSubItem.style.top = (i * 44) + "px";
			divSubItem.innerHTML = arrLUTItems[i];
			if (i % 2 == 0) {
				j(divSubItem).css("background-color","rgb(28,28,28)");
			}

			AddEvent(divSubItem, "click", m_objSelf.CallbackItemLUTItemClick);
			AddEvent(divSubItem, "mousedown", m_objSelf.CallbackSubItemMouseDown);
			AddEvent(divSubItem, "mouseup", m_objSelf.CallbackSubItemMouseUp);
			AddEvent(divSubItem, "mouseout", m_objSelf.CallbackSubItemMouseOut);
			AddEvent(divSubItem, "touchstart", m_objSelf.CallbackSubItemTouchStart);	
			AddEvent(divSubItem, "touchend", m_objSelf.CallbackSubItemTouchEnd);
			AddEvent(divSubItem, "touchcancel", m_objSelf.CallbackSubItemTouchEnd);
			
			var divSubItemIcon = document.createElement("DIV");
			divSubItemIcon.className = "DIV_DLG_ITEM_ICON";
			divSubItemIcon.style.backgroundImage = "";
			divSubItemIcon.id = i + "_" + m_objSelf.NameID + "_ICON";
			
			divSubItem.appendChild(divSubItemIcon);
			m_SubLUTContent.appendChild(divSubItem);
		}
	};
	
	this.DeleteOldDlgItemsDIV = function()
	{
		for (var i = 0; i < arrLUTItems.length; i++)
		{
			var deleteItem = $(i + "_" + m_objSelf.NameID + "_DLG_LUTSUB_ITEM");
			
			RemoveEvent(deleteItem, "click", this.CallbackItemLUTItemClick);
			RemoveEvent(deleteItem, "mousedown", this.CallbackSubItemMouseDown);
			RemoveEvent(deleteItem, "mouseout", this.CallbackSubItemMouseOut);
			RemoveEvent(deleteItem, "mouseup", this.CallbackSubItemMouseUp);
			RemoveEvent(deleteItem, "touchstart", this.CallbackSubItemTouchStart);	
			RemoveEvent(deleteItem, "touchend", this.CallbackSubItemTouchEnd);
			RemoveEvent(deleteItem, "touchcancel", this.CallbackSubItemTouchEnd);
			j(deleteItem).remove();
		}
		
		if (arrLUTItems.length < 6)
		{
			for (var i = arrLUTItems.length; i < 6; i++)
			{
				var deleteItem = $(i + "_" + m_objSelf.NameID + "_DLG_LUTSUB_ITEM");
				j(deleteItem).remove();
			}
		}
	};
	
	this.Create();
}
