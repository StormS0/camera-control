// JavaScript Document



function MenuMaskMsg(objSrc, AlertText, CallbackFunc)
{
	this.AlertText = AlertText;
	this.CallbackFunc = CallbackFunc;
	
	var m_Object = objSrc;
	var m_ObjTitle = null;
	var m_ObjTextField = null;
	var that = null;
	
	this.Create = function () 
	{
		m_Object.style.display = "none";
		
		//var divTitle = document.createElement("DIV");
		//divTitle.id = "AUTO_BAN_DIALOG_TITLE";
		//divTitle.className = "AUTO_BAN_DIALOG_TITLE";
		//m_ObjTitle = divTitle;
		//m_Object.appendChild(divTitle);
		
		var divTextField = document.createElement("DIV");
		divTextField.id="1_AUTO_BAN_DIALOG_TEXTFIELD";
		divTextField.className = "DIV_MESSAGE_DIALOG_TEXTFIELD";
		//divTextField.innerHTML = this.AlertText;
		m_Object.appendChild(divTextField);	
		m_ObjTextField = divTextField;
		that = this;
		
		var divHeadSeparator = document.createElement("DIV");
		divHeadSeparator.className = "DIV_DLG_SEPARATOR";
		divHeadSeparator.style.top = "12px";
		divHeadSeparator.style.left = "12px";
		divHeadSeparator.style.width = "252px";
	//	m_Object.appendChild(divHeadSeparator);
		
		var divLeftSeparator = document.createElement("DIV");
		divLeftSeparator.className = "DIV_DLG_SEPARATOR";
		divLeftSeparator.style.top = "12px";
		divLeftSeparator.style.left = "12px";
		divLeftSeparator.style.width = "1px";
		divLeftSeparator.style.height = "184px";
	//	m_Object.appendChild(divLeftSeparator);
		
		var divRightSeparator = document.createElement("DIV");
		divRightSeparator.className = "DIV_DLG_SEPARATOR";
		divRightSeparator.style.top = "12px";
		divRightSeparator.style.left = "263px";
		divRightSeparator.style.width = "1px";
		divRightSeparator.style.height = "185px";
	//	m_Object.appendChild(divRightSeparator);
		
		var divBottomSeparator = document.createElement("DIV");
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divBottomSeparator.style.top = "196px";
		divBottomSeparator.style.left = "12px";
		divBottomSeparator.style.width = "252px";
	//	m_Object.appendChild(divBottomSeparator);
		
		var divTopSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.top = "29px";
		divTopSeparator.style.left = "12px";
		divTopSeparator.style.width = "252px";
		m_Object.appendChild(divTopSeparator);
		
		var divDownSeparator = document.createElement("DIV");
		divDownSeparator.className = "DIV_DLG_SEPARATOR";
		divDownSeparator.style.top = "156px";
		divDownSeparator.style.left = "12px";
		divDownSeparator.style.width = "252px";
		m_Object.appendChild(divDownSeparator);
		
		var divExecuteBtn =document.createElement("DIV");
		divExecuteBtn.id = "1_AUTO_BAN_DIALOG_BTN"
		divExecuteBtn.className = "DIV_DLG_SETTING_BTN";
		divExecuteBtn.style.left = "198px";
		divExecuteBtn.innerHTML = "OK";
		AddEvent(divExecuteBtn, "click", this.CallbackBtnClick);
		AddEvent(divExecuteBtn, "mouseover", this.CallbackBtnMouseOver);
		AddEvent(divExecuteBtn, "mouseout", this.CallbackBtnMouseOut);
		AddEvent(divExecuteBtn, "mousedown", this.CallbackBtnMouseDown);
		AddEvent(divExecuteBtn, "mouseup", this.CallbackBtnMouseUp);
		AddEvent(divExecuteBtn, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divExecuteBtn, "touchend", this.CallbackBtnTouchEnd);	
		AddEvent(divExecuteBtn, "touchcancel", this.CallbackBtnTouchEnd);
		
		//var  divCanclBtn = document.createElement("DIV");
		//divCanclBtn.id = "2_AUTO_BAN_DIALOG_BTN"
		//divCanclBtn.className = "DIV_DLG_SETTING_BTN";
		//divCanclBtn.style.left = "14px";
		//divCanclBtn.innerHTML = "Cancel";
		//AddEvent(divCanclBtn, "click", this.CallbackBtnClick);
		//AddEvent(divCanclBtn, "mouseover", this.CallbackBtnMouseOver);
		//AddEvent(divCanclBtn, "mouseout", this.CallbackBtnMouseOut);
		//AddEvent(divCanclBtn, "mousedown", this.CallbackBtnMouseDown);
		//AddEvent(divCanclBtn, "mouseup", this.CallbackBtnMouseUp);
		//AddEvent(divCanclBtn, "touchstart", this.CallbackBtnTouchStart);	
		//AddEvent(divCanclBtn, "touchend", this.CallbackBtnTouchEnd);	
		//AddEvent(divCanclBtn, "touchcancel", this.CallbackBtnTouchEnd);
		
		m_Object.appendChild(divExecuteBtn);
		//m_Object.appendChild(divCanclBtn);
		
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		/*if(1 == parseInt(objSrc.id))
		{	
			if (that.CallbackFunc)
			{
				that.CallbackFunc();
			}
			//g_AutoBalanceIsExcuting = true;
		}
		else//cancel
		{
			objMaskDialog.style.display = "none";
		}*/
		m_Object.style.display = "none";
		//objMaskDialog.style.display = "none";
	};
	
	this.CallbackBtnMouseOver = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackBtnMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		objSrc.style.color = "rgb(23,23,23)";
	};
	
	this.CallbackBtnMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		objSrc.style.color = "rgb(230,230,230)";
	};
	
	this.ShowDialog = function()
	{
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";	
			return;
		}
		if("none" == m_Object.style.display) {
			m_Object.style.display = "block";
		}
	
	}
	
	this.SetText = function(AlertText)
	{
		m_ObjTextField.innerHTML = AlertText;
	}
	
	this.IsDialogShow = function()
	{
		var b_IsDialogShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDialogShow = false;
		}
		return b_IsDialogShow;
	};
	
	this.SetTitle = function(objTitle)
	{
		m_ObjTitle.innerHTML = objTitle;
	}
	this.Create();
}
