// JavaScript Document

function SQFPSDialog(objAttachSrc, objFPSValue, nDftSelect, funcCallback, objName)
{	
	this.AttachSrc = objAttachSrc;
	this.SelectedIndex = nDftSelect;
	this.SelectedValue = objFPSValue;
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	this.arrValues = new Array();

	var arrSQFPSItems=["On","Off"];
	var m_objSelf = this;
	var m_objOldItem = null;
	var m_Object = null;							//MainContainer
	var m_ObjSelectContainer = null;
	var m_ObjSQDataContainer = null;
	var m_ObjPlusBtn = null;
	var m_ObjMinusBtn = null;
	var m_TmpSelectedIndex = nDftSelect;
	var m_ObjShowFPSField = "";
	var m_ObjTitle = "";
	var m_ObjCurrentData = "";
	var m_iIndex = 0;
	var m_ObjPreoff = false;
	var IsFristOn = null;
	 
	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		divMainContainer.className = "DIV_DLG_MAIN";
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);
		divMainContainer.style.display = "none";
		m_Object = divMainContainer;

		var divTitle = document.createElement("DIV");
		divTitle.className = "DIV_DLG_TITLE";
		divMainContainer.appendChild(divTitle);
		m_ObjTitle = divTitle;
		
		var divTopSeparator = document.createElement("DIV");
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.left = "12px";
		divTopSeparator.style.top = "27px";
		divMainContainer.appendChild(divTopSeparator);
		
		var divArrow = document.createElement("DIV");
		divArrow.className = "DIV_DLG_LEFT_ARROW";
		divMainContainer.appendChild(divArrow);
		
		var divSubSelect = document.createElement("DIV");
		divSubSelect.className = "DIV_DLG_SUB";
		divMainContainer.appendChild(divSubSelect);
		m_ObjSelectContainer = divSubSelect;
		
		var divMainBottomSeparator = document.createElement("DIV");
		divMainBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divMainBottomSeparator.style.top = "264px";
		divSubSelect.appendChild(divMainBottomSeparator);
		
		var divSelectArea = document.createElement("DIV");
		divSelectArea.className = "DIV_DLG_ITEMAREA";
		divSubSelect.appendChild(divSelectArea);
		
		//create Items
		for (var i = 0; i < arrSQFPSItems.length; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.className = "DIV_DLG_ITEM";
			divItem.style.top = (i * 44) + "px";
			divItem.innerHTML = arrSQFPSItems[i];
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			AddEvent(divItem, "click", this.CallbackItemClick);
			AddEvent(divItem, "mousedown", this.CallbackItemMouseDown);
			AddEvent(divItem, "mouseup", this.CallbackItemMouseUp);
			AddEvent(divItem, "mouseout", this.CallbackItemMouseOut);
			AddEvent(divItem, "touchstart", this.CallbackItemTouchStart);	
			AddEvent(divItem, "touchend", this.CallbackItemTouchEnd);
			AddEvent(divItem, "touchcancel", this.CallbackItemTouchEnd);
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
			
			var divItemIcon = document.createElement("DIV");
			divItemIcon.className = "DIV_DLG_ITEM_ICON";
			
			if (this.SelectedIndex == i)
			{
				m_objOldItem = divItem;
				divItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divItem.style.color = "rgb(255,170,0)";
			}
			divItem.appendChild(divItemIcon);
			divSelectArea.appendChild(divItem);
		}
		
		var divCurrentData = document.createElement("DIV");
		divCurrentData.id = "20_DIV_DLG_FPS_CURRENT_DATA";
		divCurrentData.className = "DIV_DLG_FPS_CURRENT_DATA";
		$("0_SQFPS_DLG_ITEM").appendChild(divCurrentData);
		m_ObjCurrentData = divCurrentData;
		//AddEvent(divCurrentData, "click", this.CallbackItemClick);
		AddEvent(divCurrentData, "mousedown", this.CallbackItemMouseDown);
		AddEvent(divCurrentData, "mouseup", this.CallbackItemMouseUp);
		AddEvent(divCurrentData, "touchstart", this.CallbackItemTouchStart);	
		AddEvent(divCurrentData, "touchend", this.CallbackItemTouchEnd);
		AddEvent(divCurrentData, "touchcancel", this.CallbackItemTouchEnd);
		
		var divSecPageArrow = document.createElement("DIV");
		divSecPageArrow.id = "21_DIV_DLG_SEC_PAGE_ARROW";
		divSecPageArrow.className = "DIV_DLG_SEC_PAGE_ARROW";
		divSecPageArrow.innerHTML= ">";
		$("0_SQFPS_DLG_ITEM").appendChild(divSecPageArrow);
		
		for (var i = 0; i < 4; i++)
		{
			var divItem = document.createElement("DIV");
			divItem.className = "DIV_DLG_ITEM";
			divItem.style.top = 88 + (i * 44) + "px";
			divItem.id = i + "_" + this.NameID + "_DLG_ITEM";
			divSelectArea.appendChild(divItem);
			if (i % 2 == 0)
			{
				j(divItem).css("background-color","rgb(28,28,28)");
			}
		}
		
		var divCancelButton = document.createElement("DIV");
		divCancelButton.className = "DIV_DLG_BUTTON";
		divCancelButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divCancelButton.style.left = -4 + "px";
		divCancelButton.style.top = 264 + "px";
		this.AddButtonEvents(divCancelButton, "Cancel");
		divSubSelect.appendChild(divCancelButton);
		
		var divOKButton = document.createElement("DIV");
		divOKButton.className = "DIV_DLG_BUTTON";
		divOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divOKButton.style.left = 158 + "px";
		divOKButton.style.top = 264 + "px";
		divOKButton.innerHTML = "OK";
		
		this.AddButtonEvents(divOKButton, "OK");
		divSubSelect.appendChild(divOKButton);
		/****************************************************
		*		continuous Area
		****************************************************/
		var divContinuous = document.createElement("DIV");
		divContinuous.className = "DIV_DLG_SUB";
		divContinuous.style.display = "none";
		divMainContainer.appendChild(divContinuous);
		m_ObjSQDataContainer = divContinuous;

		var divSQDataField = document.createElement("DIV");
		divSQDataField.className = "DIV_DLG_TEXT_FIELD";
		divSQDataField.id = "0_DIV_" + this.NameID + "_DLG_TEXTFIELD";
		divSQDataField.style.top = 110 + "px";
		divContinuous.appendChild(divSQDataField);
		m_ObjShowFPSField = divSQDataField;

		var divMinusBtn = document.createElement("DIV");
		divMinusBtn.id = "4_DIV_" + this.NameID + "_DLG_BTN";
		divMinusBtn.className = "DIV_DLG_MINUS_BTN";
		divMinusBtn.style.top = 110 + "px";
		divContinuous.appendChild(divMinusBtn);
		var arrMinusBtnImgs = ["Parts_CR_S_CC_Spinner_Button_Minus_Normal", "Parts_CR_S_CC_Spinner_Button_Minus_Pressed", "Parts_CR_S_CC_Spinner_Button_Minus_Normal", "Parts_CR_S_CC_Spinner_Button_Minus_Normal", ""];
		divMinusBtn.userData = new ButtonCtrl(divMinusBtn, arrMinusBtnImgs, this.ContinuousClick);
		m_ObjMinusBtn = divMinusBtn;
			
		var divPlusBtn = document.createElement("DIV");
		divPlusBtn.id = "5_DIV_" + this.NameID + "_DLG_BTN";
		divPlusBtn.className = "DIV_DLG_PLUS_BTN";
		divPlusBtn.style.top = 110 + "px";
		divContinuous.appendChild(divPlusBtn);
		var arrPlusBtnImgs = ["Parts_CR_S_CC_Spinner_Button_Plus_Normal", "Parts_CR_S_CC_Spinner_Button_Plus_Pressed", "Parts_CR_S_CC_Spinner_Button_Plus_Normal", "Parts_CR_S_CC_Spinner_Button_Plus_Normal", ""];
		divPlusBtn.userData = new ButtonCtrl(divPlusBtn, arrPlusBtnImgs, this.ContinuousClick);
		m_ObjPlusBtn = divPlusBtn;
		
		var divSubBottomSeparator = document.createElement("DIV");
		divSubBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divSubBottomSeparator.style.top = "264px";
		divContinuous.appendChild(divSubBottomSeparator);
		
		var divBackButton = document.createElement("DIV");
		divBackButton.className = "DIV_DLG_BACK_BTN";
		divBackButton.style.top = "264px";
		divBackButton.id = "6_DIV_" + this.NameID + "_DLG_BTN";
		this.AddButtonEvents(divBackButton, "Back");
		divContinuous.appendChild(divBackButton);
		
	    var divConOKButton = document.createElement("DIV");
		divConOKButton.className = "DIV_DLG_BUTTON";
		divConOKButton.id = "7_DIV_" + this.NameID + "_DLG_BTN";
		divConOKButton.style.left = 158 + "px";
		divConOKButton.style.top = 264 + "px";
		this.AddButtonEvents(divConOKButton, "OK");
		divContinuous.appendChild(divConOKButton);
	};
	
	this.AddButtonEvents = function(objButton, strShowText)
	{
		AddEvent(objButton, "click", this.CallbackButtonClick);
		AddEvent(objButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(objButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(objButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(objButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(objButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(objButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(objButton, "touchcancel", this.CallbackBtnTouchCancel);
		objButton.innerHTML = strShowText;
	};
	
	this.ShowDialog = function()
	{
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			m_Object.style.display = "none";	//Close Dialog
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			return;
		}
		
		if (m_Object.style.display == "block")
		{
			m_Object.style.display = "none";//Close Dialog
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else
		{
			m_Object.style.display = "block";	
			m_ObjSQDataContainer.style.display = "none";
			m_ObjSelectContainer.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
		}
		var objSelectedItem = $(m_objSelf.SelectedIndex + "_" + this.NameID + "_DLG_ITEM");
		if (m_objOldItem)
		{
			m_objOldItem.children[0].style.backgroundImage = "";
			m_objOldItem.style.color = "rgb(230,230,230)";
		}
		if (objSelectedItem)
		{
			if(m_objSelf.SelectedIndex == 0)
			{
			  j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(255,170,0)"});
			  IsFristOn = true;
			}
			
			m_ObjPreoff = false;
			if(m_objSelf.SelectedIndex == 1)
			{
				m_ObjPreoff = true;
				IsFristOn = false;
				
			}
			
			objSelectedItem.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSelectedItem.style.color = "rgb(255,170,0)";
			m_objOldItem = objSelectedItem;
			
		}
		m_objSelf.SelectedValue = $("CLICK_DIV_SQFPS").innerHTML;
		j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
		
		m_objSelf.SwitchMaxMinValue(parseInt(m_objSelf.SelectedValue));
	}
	
	this.CallbackItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (objSrc.id == "" || parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);		//20:First Page Data 21:First Page Arrow
		}
		// Old Select Item 
		j(m_objOldItem).css("color","rgb(230,230,230)");
		j("#" + m_objOldItem.id + " > div").css("color","rgb(230,230,230)");
		m_objOldItem.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Normal.png)";
		//Current Select Item
		j(objSrc).css("color","rgb(255,170,0)");
		j("#" + objSrc.id + " > div").css("color","rgb(255,170,0)");
		objSrc.children[0].style.background = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		m_objOldItem = objSrc;
		m_TmpSelectedIndex = parseInt(objSrc.id);
		switch(parseInt(objSrc.id))
		{
			case 0:
			//On  :Switch Page Fst->Sec
			m_ObjSQDataContainer.style.display = "block";
			m_ObjSelectContainer.style.display = "none";
			j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
			var CurrentValue = $("CLICK_DIV_SQFPS").innerHTML;
			if("Off" == CurrentValue && !isNaN(g_SQFPSValue))
			{
				CurrentValue = g_SQFPSValue+"FPS";
			}
			//SandQ Motion Setting: On
			m_objSelf.CallbackFunc(objSrc, m_TmpSelectedIndex, CurrentValue);
			j("#0_DIV_SQFPS_DLG_TEXTFIELD").text(j("#20_DIV_DLG_FPS_CURRENT_DATA").text());
			break;
			case 1:
			//SandQ Motion Setting: Off
			j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
			break;
			default:
			break;
		}
	};
	
	this.CallbackItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);	//20:First Page Data 21:First Page Arrow
		}
		if(typeof(objSrc.children[1]) != "undefined")
		{
			j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(0,0,0)"});
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes()|| parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_objOldItem)
		{
			if(typeof(objSrc.children[1]) != "undefined")
			{
				j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(255,170,0)"});
			}
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			if(typeof(objSrc.children[1]) != "undefined")
			{
				j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(230,230,230)"});
			}
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes()|| parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);
		}
		objEvent.preventDefault();
		if(typeof(objSrc.children[1]) != "undefined")
		{
			j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(0,0,0)"});
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes()|| 	parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);
		}

		if (objSrc == m_objOldItem)
		{
			objSrc.style.color = "rgb(255,170,0)";
			if(typeof(objSrc.children[1]) != "undefined")
			{
				j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
				j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(255,170,0)"});
			}
		}
		else
		{
			if(typeof(objSrc.children[1]) != "undefined")
			{
				j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
				j("#20_DIV_DLG_FPS_CURRENT_DATA").css({color:"rgb(230,230,230)"});
			}
			objSrc.style.color = "rgb(230,230,230)";
		}

		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
		
		
		//click evnet//////////////////////////////////////
		if (objSrc.id == "" || parseInt(objSrc.id) == 20 || parseInt(objSrc.id) == 21)
		{
			objSrc = GetParent(objSrc);		//20:First Page Data 21:First Page Arrow
		}
		// Old Select Item 
		j(m_objOldItem).css("color","rgb(230,230,230)");
		j("#" + m_objOldItem.id + " > div").css("color","rgb(230,230,230)");
		m_objOldItem.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Normal.png)";
		//Current Select Item
		j(objSrc).css("color","rgb(255,170,0)");
		j("#" + objSrc.id + " > div").css("color","rgb(255,170,0)");
		objSrc.children[0].style.background = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		m_objOldItem = objSrc;
		m_TmpSelectedIndex = parseInt(objSrc.id);
		switch(parseInt(objSrc.id))
		{
			case 0:
			//On  :Switch Page Fst->Sec
			m_ObjSQDataContainer.style.display = "block";
			m_ObjSelectContainer.style.display = "none";
			j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
			var CurrentValue = $("CLICK_DIV_SQFPS").innerHTML;
			if("Off" == CurrentValue && !isNaN(g_SQFPSValue))
			{
				CurrentValue = g_SQFPSValue+"FPS";
			}
			//SandQ Motion Setting: On
			m_objSelf.CallbackFunc(objSrc, m_TmpSelectedIndex, CurrentValue);
			j("#0_DIV_SQFPS_DLG_TEXTFIELD").text(j("#20_DIV_DLG_FPS_CURRENT_DATA").text());
			break;
			case 1:
			//SandQ Motion Setting: Off
			j("#21_DIV_DLG_SEC_PAGE_ARROW").css("color","rgb(153,153,153)");
			break;
			default:
			break;
		}
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}

		m_Object.style.display = "none";	//close Dialog
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
			 	m_objSelf.SelectedValue = $("CLICK_DIV_SQFPS").innerHTML;	//Cancel Button
				if(m_ObjPreoff)
				{
					m_objSelf.CallbackFunc(m_objSelf.AttachSrc, 1, m_objSelf.SelectedValue);
				} 
			break;
			case 1:
			case 7:
			if (null != m_objSelf.CallbackFunc) //Ok Button
			{
				m_objSelf.SelectedIndex = m_TmpSelectedIndex;
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, m_objSelf.SelectedIndex, m_objSelf.SelectedValue);
			}
			break;
			case 6:
			m_Object.style.display = "block";		//Back button
			m_ObjSQDataContainer.style.display = "none";
			m_ObjSelectContainer.style.display = "block";
			m_ObjCurrentData.innerHTML = m_ObjShowFPSField.innerHTML;
			break;
			default:
			break;
		}
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objEvent.preventDefault();
		objSrc.style.color = "rgb(0,0,0)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";	//Back button
			break;
		}
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";	//Back button
			break;
		}
		switch(parseInt(objSrc.id))
		{
			case 0:
			m_objSelf.SelectedValue = $("CLICK_DIV_SQFPS").innerHTML;		//Cancel Button
			m_Object.style.display = "none";
			if(m_ObjPreoff)
			{
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, 1, m_objSelf.SelectedValue);
			}
			break;
			case 1:
			case 7:
			if (null != m_objSelf.CallbackFunc) 						//Ok Button
			{
				m_objSelf.SelectedIndex = m_TmpSelectedIndex;
				m_Object.style.display = "none";
				m_objSelf.CallbackFunc(m_objSelf.AttachSrc, m_objSelf.SelectedIndex, m_objSelf.SelectedValue);
			}
			break;
			case 6:
			m_Object.style.display = "block";		//Back button
			m_ObjSQDataContainer.style.display = "none";
			m_ObjSelectContainer.style.display = "block";
			m_ObjCurrentData.innerHTML = m_ObjShowFPSField.innerHTML;
			break;
			default:
			break;
		}
	};
	
	this.CallbackBtnTouchCancel = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";	//Back button
			break;
		}
	};
	
	this.ContinuousClick = function(objSrc)
	{
		switch(parseInt(objSrc.id))
		{
			case 4:
			//Minus Button
			var value = parseInt(m_ObjShowFPSField.innerHTML);
			if(m_iIndex > 0 && !(isNaN(m_objSelf.arrValues[m_iIndex])))
			{
				value =  parseInt(m_objSelf.arrValues[--m_iIndex]);
			}
			m_ObjShowFPSField.innerHTML = value +"FPS";
			m_Object.style.display = "block";
			break;
			case 5:
			 //Plus Button
		   	var value = parseInt(m_ObjShowFPSField.innerHTML);
			if(m_iIndex < m_objSelf.arrValues.length-1 && !(isNaN(m_objSelf.arrValues[m_iIndex])))
			{
				value = parseInt(m_objSelf.arrValues[++m_iIndex]);
			}
			m_ObjShowFPSField.innerHTML = value +"FPS";
			m_Object.style.display = "block";
			break;
			default:
			break;
		}
		m_objSelf.SwitchMaxMinValue(parseInt(m_ObjShowFPSField.innerHTML));
		m_objSelf.SelectedValue = m_ObjShowFPSField.innerHTML;
	};
	
	this.CallbackButtonMouseOver = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";	//Back button
			break;
		}
	};
	
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";	//Back button
			break;
		}
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objEvent.preventDefault();
		objSrc.style.color = "rgb(0,0,0)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";	//Ok Button  and Cancel Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";	//Back button
			break;
		}
	};
	
	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		switch(parseInt(objSrc.id))
		{
			case 0:
			case 1:
			case 7:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";	//Ok Button
			break;
			case 6:
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";	//Back button
			break;
		}
	};
		
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.SetSelect = function(seleIndex)
	{
		m_objSelf.SelectedIndex = seleIndex;
		m_TmpSelectedIndex = m_objSelf.SelectedIndex;
	};
	
	this.SwitchMaxMinValue = function (iValue)
	{
		if (m_objSelf.arrValues[0] == m_objSelf.arrValues[m_objSelf.arrValues.length - 1])
		{
			m_objSelf.SetPlusBtnDisabled(true);
			m_objSelf.SetMinusBtnDisabled(true);
		}
		else if (iValue >= m_objSelf.arrValues[m_objSelf.arrValues.length - 1])
		{
			m_objSelf.SetPlusBtnDisabled(true);
			m_objSelf.SetMinusBtnDisabled(false);
		}
		else if (iValue <= m_objSelf.arrValues[0])
		{
			m_objSelf.SetPlusBtnDisabled(false);
			m_objSelf.SetMinusBtnDisabled(true);
		}
		else
		{
			m_objSelf.SetPlusBtnDisabled(false);
			m_objSelf.SetMinusBtnDisabled(false);
		}
	}
	
	this.SetsqMotionItems = function(arrItems)
	{
		m_objSelf.arrValues = arrItems;
	};
	
	this.SetSqMotionIndex = function(curValue)
	{
		m_iIndex = m_objSelf.GetTheIndexOfArray(m_objSelf.arrValues, curValue);
	};
	
	this.SetPlusBtnDisabled = function (bTrue)
	{	
		m_ObjPlusBtn.userData.SetDisabled(bTrue);
	}
	
	this.SetMinusBtnDisabled = function (bTrue)
	{
		m_ObjMinusBtn.userData.SetDisabled(bTrue);
	}
	
	this.SetSQMotionText = function(strText)
	{
		m_ObjCurrentData.innerHTML = strText;		//First Page Data Text
		m_ObjShowFPSField.innerHTML = strText;		//Sec Page Data Text
		m_objSelf.SelectedValue = strText;
		m_objSelf.SwitchMaxMinValue(parseInt(m_objSelf.SelectedValue));
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};
	
	this.GetTheIndexOfArray = function(arrItems, curValue)
	{
		var Index = -1;
		for (var i = 0; i < arrItems.length; i++)
		{
			if (arrItems[i] == curValue)
			{
				Index = i;
				break;
			}
		}
		return Index;
	};
	
	this.Create();
}
