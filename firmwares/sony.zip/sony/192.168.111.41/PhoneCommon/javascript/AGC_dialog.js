// JavaScript Document
function AGCDialog(objAttachSrc, nDftSelect, funcCallback, objName)
{
	this.AttachSrc = objAttachSrc;
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	
	var AGCItems = ["On", "Off"];
	var DftSelectValue = nDftSelect;
	var m_objSelf = this;
	var m_Object = null;
	var m_CurrentObj = null;
	var m_ObjTitle = null;
	var m_SelectedObj = null;
	
	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		var divContainer = document.createElement("DIV");
		var divTitle = document.createElement("DIV");
		var divTopSeparator = document.createElement("DIV");
		var divBottomSeparator = document.createElement("DIV");
		
		divMainContainer.appendChild(divTitle);
		divMainContainer.appendChild(divContainer);
		
		divMainContainer.className = "DIV_DLG_MAIN";
		divContainer.className = "DIV_DLG_SUB";
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		
		divTopSeparator.style.top = "-1px";
		divBottomSeparator.style.top = "264px";
		divMainContainer.style.display = "none";
		m_Object = divMainContainer;
		
		var divMainSubContainer = document.createElement("DIV");
		
		divMainSubContainer.className = "DIV_DLG_ITEMAREA";
		
		if (AGCItems.length > 6)
		{
			divMainSubContainer.style.overflowY = "scroll";
		}
		else
		{
			divMainSubContainer.style.overflowY = "hidden";
		}
		
		for (var i = 0; i < AGCItems.length; i++)
		{
			var divMainItem = document.createElement("DIV");

			divMainItem.className = "DIV_DLG_ITEM";
			divMainItem.style.top = (i * 44) + "px";
			divMainItem.innerHTML = AGCItems[i];// value from .html
			//divMainItem.style.backgroundImage = "URL(PhoneCommon/images/dlg_item_bg_1.gif)";
			if (i % 2 == 0)
			{
				j(divMainItem).css("background-color","rgb(28,28,28)");
			}
			divMainItem.id = i + "_" + this.NameID;

			AddEvent(divMainItem, "click", this.CallbackMainItemClick);
			AddEvent(divMainItem, "mousedown", this.CallbackMainItemMouseDown);
			AddEvent(divMainItem, "mouseup", this.CallbackMainItemMouseUp);
			AddEvent(divMainItem, "mouseout", this.CallbackMainItemMouseOut);
			AddEvent(divMainItem, "touchstart", this.CallbackMainItemTouchStart);	
			AddEvent(divMainItem, "touchend", this.CallbackMainItemTouchEnd);
			AddEvent(divMainItem, "touchcancel", this.CallbackMainItemTouchEnd);
			
			var divMainItemIcon = document.createElement("DIV");
			divMainItemIcon.className = "DIV_DLG_ITEM_ICON";
			divMainItemIcon.style.backgroundImage = "";
			divMainItemIcon.id = i + "_" + this.NameID + "_ICON";
			
			divMainItem.appendChild(divMainItemIcon);
			divMainSubContainer.appendChild(divMainItem);
			if (DftSelectValue == AGCItems[i])
			{
				divMainItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divMainItem.style.color = "rgb(255, 170, 0)";
				m_SelectedObj = divMainItem;
				m_CurrentObj = divMainItem;
			}
		}
		
		if (AGCItems.length < 6)
		{
			for (var m = AGCItems.length; m < 6; m++)
			{
				var divMainItem = document.createElement("DIV");
				divMainItem.className = "DIV_DLG_ITEM";
				divMainItem.style.top = (m * 44) + "px";
				//divMainItem.style.backgroundImage = "URL(PhoneCommon/images/dlg_item_bg_1.gif)";
				if (m % 2 == 0)
				{
					j(divMainItem).css("background-color","rgb(28,28,28)");
				}
				divMainSubContainer.appendChild(divMainItem);
			}
		}
		
		divTitle.className = "DIV_DLG_TITLE";
		
		m_ObjTitle = divTitle;
		
		var divYesButton = document.createElement("DIV");
		divYesButton.className = "DIV_DLG_BUTTON";
		divYesButton.innerHTML = "OK";
		divYesButton.style.left = 158 + "px";
		divYesButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divYesButton.style.top = 264 + "px";
		
		AddEvent(divYesButton, "click", this.CallbackButtonClick);
		AddEvent(divYesButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divYesButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divYesButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divYesButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divYesButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(divYesButton, "touchcancel", this.CallbackBtnTouchEnd);
		
		var divNoButton = document.createElement("DIV");
		divNoButton.className = "DIV_DLG_BUTTON";
		divNoButton.innerHTML = "Cancel";
		divNoButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divNoButton.style.left = -4 + "px";
		divNoButton.style.top = 264 + "px";
	
		AddEvent(divNoButton, "click", this.CallbackButtonClick);
		AddEvent(divNoButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divNoButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divNoButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divNoButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divNoButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(divNoButton, "touchcancel", this.CallbackBtnTouchEnd);	
		
		//divContainer.appendChild(divTitle);
		divContainer.appendChild(divTopSeparator);
		divContainer.appendChild(divMainSubContainer);
		divContainer.appendChild(divBottomSeparator);
		divContainer.appendChild(divYesButton);
		divContainer.appendChild(divNoButton);
		
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);

//		divMainContainer.style.left = parseInt(parseInt(this.AttachSrc.style.left) + 100) + "px";
//		divMainContainer.style.top = parseInt(this.AttachSrc.style.top) - parseInt(divMainContainer.style.height) / 2 + "px";
	};
	
	this.ShowDialog = function()
	{
		if ((arguments.length == 1) && (arguments[0] == false))
		{
			if (m_Object.style.display == "block")
			{
				$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			}
			m_Object.style.display = "none";
			return;
		}
		
		if (m_Object.style.display == "block")
		{
			m_Object.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		}
		else
		{
			if (m_CurrentObj)
			{
				m_CurrentObj.children[0].style.backgroundImage = "";
				m_CurrentObj.style.color = "rgb(230, 230, 230)";
			}
				
			if (m_SelectedObj) 
			{
				m_SelectedObj.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				m_SelectedObj.style.color = "rgb(255, 170, 0)";
				m_CurrentObj = m_SelectedObj;
			}
			m_Object.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
		}
	}
	
	this.CallbackMainItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_CurrentObj)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}
		
	};
	
	this.CallbackMainItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};

	this.CallbackMainItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (objSrc == m_CurrentObj)
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}		
	};
	
	this.CallbackMainItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackMainItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (m_CurrentObj)
		{
			m_CurrentObj.children[0].style.backgroundImage = "";
			m_CurrentObj.style.color = "rgb(230, 230, 230)";
		}
		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		objSrc.style.color = "rgb(255, 170, 0)";
		m_CurrentObj = objSrc;
	
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}	
	};

	this.CallbackMainItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		if (m_CurrentObj)
		{
			m_CurrentObj.children[0].style.backgroundImage = "";
			m_CurrentObj.style.color = "rgb(230, 230, 230)";
		}
		
		if (objSrc.hasChildNodes())
		{
			objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			objSrc.style.color = "rgb(255, 170, 0)";
			m_CurrentObj = objSrc;
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			GetParent(objSrc).style.color = "rgb(255, 170, 0)";
			m_CurrentObj = GetParent(objSrc);
		}
		
	};
	
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		m_Object.style.display = "none";
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
	
		if (null != m_objSelf.CallbackFunc)
		{
			if (1 == parseInt(objSrc.id))
			{
				m_SelectedObj = m_CurrentObj;
				if (m_SelectedObj)
				{
					m_objSelf.CallbackFunc(m_objSelf.AttachSrc, AGCItems[parseInt(m_SelectedObj.id)]);
				}
			}else
			{	
				if (m_SelectedObj)
				{
					m_objSelf.CallbackFunc(m_objSelf.AttachSrc, -1, "Cancel");
				}
			}
		}
			
	};
	
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.SetSelect = function(selectedValue)
	{
		var selectedIndex = j.inArray(selectedValue, AGCItems);//return index in array
		m_SelectedObj = $(selectedIndex + "_" + this.NameID);
	};
	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";		
	};

	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";		
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		objEvent.preventDefault();
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if ("" == objSrc.id)
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(230,230,230)";
		objSrc.style.backgroundImage  = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		
		m_Object.style.display = "none";
		$("DIV_BUTTON_MASKDIALOG").style.display = "none";
		
		if (null != m_objSelf.CallbackFunc)
		{
			if (1 == parseInt(objSrc.id))
			{
				m_SelectedObj = m_CurrentObj;
				if (m_SelectedObj)
				{
					m_objSelf.CallbackFunc(m_objSelf.AttachSrc, AGCItems[parseInt(m_SelectedObj.id)]);
				}
			}else
			{	
				if (m_SelectedObj)
				{
					m_objSelf.CallbackFunc(m_objSelf.AttachSrc, -1, "Cancel");
				}
			}
		}
	};
	
	this.IsDialogShow = function()
	{
		var b_IsDlgShow = true;
		if(m_Object.style.display == "none")
		{
			b_IsDlgShow = false;
		}
		return b_IsDlgShow;
	};
	
	this.Create();
}
