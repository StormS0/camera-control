// JavaScript Document

function GammaDialog(objAttachSrc, gammaType, dltValue, funcCallback, objName)
{
	this.AttachSrc = objAttachSrc;
	this.RootURL = GetRootPath();
	this.CallbackFunc = funcCallback;
	this.NameID = objName;
	this.IsDisplay = false;
	
	var m_SubContentItem = null;
	var m_MainContentItem = null;
	var m_objSelf = this;
	var m_MainContainer = null;
	var m_MainContent = null;
	var m_SubContentArray = new Array();
	var m_ObjTitle = null;
	var m_MainItemClicked = false;
	
	var m_GammaTypeItems = ["STD","HG","User","S-Log2", "S-Log3"];
	var m_STDItems = ["STD1 DVW", "STD2 X4.5", "STD3 X3.5", "STD4 240M", "STD5 R709", "STD6 X5.0"];
	var m_HGItems = ["HG1 3250G36","HG2 4600G30","HG3 3259G40","HG4 4609G33","HG7 8009G40","HG8 8009G33"];
	var m_UserItems = ["User 1","User 2","User 3","User 4","User 5"];
	var m_SLOG2Items = ["S-Log2"];
	var m_SLOG3Items = ["S-Log3"];
	var m_MainSelectedType = gammaType;
	var m_SelectedValue = dltValue;
	var m_OKButton = null;
	var m_SubOKButton = null;
	var m_CancelButton = null;
	var m_BackButton = null;
	var m_OldGammaType = "";
	var m_BackGammaItem = null;//to select S_Log3 if type is not S_Log3 when back button clicked  
	var m_OldGammaValue = "";
	var m_IsFirstDisplay = false;
	var m_MainSelectedTypeIndex = -1; //current Gamma type
	
	this.Create = function()
	{
		var divMainContainer = document.createElement("DIV");
		var divArrowContainer = document.createElement("DIV");
		var divContainer = document.createElement("DIV");
		var divTitle = document.createElement("DIV");
		var divTopSeparator = document.createElement("DIV");
		var divBottomSeparator = document.createElement("DIV");
		
		divMainContainer.appendChild(divTitle);
		divMainContainer.appendChild(divContainer);
		divMainContainer.className = "DIV_DLG_MAIN";
		divMainContainer.style.display = "none";
		divContainer.className = "DIV_DLG_SUB";
		divTopSeparator.className = "DIV_DLG_SEPARATOR";
		divBottomSeparator.className = "DIV_DLG_SEPARATOR";
		divTopSeparator.style.top = "-1px";
		divBottomSeparator.style.top = "265px";
		
		m_MainContainer = divMainContainer;

		var divMainSubContainer = document.createElement("DIV");
		var divItemSubContainer = document.createElement("DIV");
		divMainSubContainer.className = "DIV_DLG_ITEMAREA";
		
		
		m_MainContent = divMainSubContainer;
		
		for (var i = 0; i < m_GammaTypeItems.length; i++)
		{
			var divMainItem = document.createElement("DIV");
			var divGammaArrow = document.createElement("DIV");
			divMainItem.className = "DIV_DLG_ITEM";
			divMainItem.style.top = (i * 44) + "px";
			divMainItem.innerHTML = m_GammaTypeItems[i];
			divMainItem.id = i + "_" + this.NameID;
			if (m_MainSelectedType == m_GammaTypeItems[i])
			{
				divMainItem.style.color = "rgb(255,170,0)";
			}
			if (i % 2 == 0)
			{
				j(divMainItem).css("background-color","rgb(28,28,28)");
			}
			
			var divMainItemIcon = document.createElement("DIV");
			divMainItemIcon.className = "DIV_DLG_ITEM_ICON";
			divMainItemIcon.style.backgroundImage = "";
			divMainItemIcon.id = i + "_GAMMA_TYPEITEM_ICON";
			
			divMainItem.appendChild(divMainItemIcon);
			if(i < m_GammaTypeItems.length - 2)
			{
			divGammaArrow.className = "DIV_DLG_ARROW";
			divGammaArrow.innerHTML = ">";
			divGammaArrow.id = i + "_GAMMA_ARROW";
			divMainItem.appendChild(divGammaArrow);
			}
			
			if (m_MainSelectedType == m_GammaTypeItems[i])
			{
				divMainItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divMainItemIcon.style.backgroundRepeat = "no-repeat";
				divMainItem.style.color = "rgb(255, 170, 0)";
				m_MainSelectedType = m_GammaTypeItems[i];
			}
			AddEvent(divMainItem, "click", this.CallbackMainItemClick);
			AddEvent(divMainItem, "mouseout", this.CallbackMainItemMouseOut);
			AddEvent(divMainItem, "mousedown", this.CallbackMainItemMouseDown);
			AddEvent(divMainItem, "mouseup", this.CallbackMainItemMouseUp);
			AddEvent(divMainItem, "touchstart", this.CallbackMainItemTouchStart);	
			AddEvent(divMainItem, "touchend", this.CallbackMainItemTouchEnd);
			AddEvent(divMainItem, "touchcancel", this.CallbackMainItemTouchEnd);
			
			divMainSubContainer.appendChild(divMainItem);
		}
		
		if (m_GammaTypeItems.length < 6)
		{
			for (var m = m_GammaTypeItems.length; m < 6; m++)
			{
				var divMainItem = document.createElement("DIV");
				divMainItem.className = "DIV_DLG_ITEM";
				divMainItem.style.top = (m * 44) + "px";
				if (m % 2 == 0)
				{
					j(divMainItem).css("background-color","rgb(28,28,28)");
				}
				divMainSubContainer.appendChild(divMainItem);
			}
		}

		var divSTDContent = document.createElement("DIV");
		divSTDContent.className = "DIV_DLG_ITEMAREA";
		divSTDContent.style.display = "none";
				
		if (m_STDItems.length > 6)
		{
			divSTDContent.style.overflowY = "scroll";
		}
		else
		{
			divSTDContent.style.overflowY = "hidden";
		}
		
		for (var i = 0; i < m_STDItems.length; i++)
		{
			var divSTDItem = document.createElement("DIV");
			divSTDItem.className = "DIV_DLG_ITEM";
			divSTDItem.style.top = (i * 44) + "px";
			divSTDItem.innerHTML = m_STDItems[i];
			divSTDItem.id = i + "_GAMMA_STD_ITEM";
			if (i % 2 == 0)
			{
				j(divSTDItem).css("background-color","rgb(28,28,28)");
			}
			
			if (m_STDItems.length > 6)
			{
				divSTDItem.style.width = "196px";
			}
			else
			{
				divSTDItem.style.width = "208px";
			}
			
			var divSTDItemIcon = document.createElement("DIV");
			divSTDItemIcon.className = "DIV_DLG_ITEM_ICON";
			divSTDItemIcon.style.backgroundImage = "";
			divSTDItemIcon.id = i + "_GAMMA_STDITEM_ICON";

			
			divSTDItem.appendChild(divSTDItemIcon);
				
			if (m_SelectedValue == m_STDItems[i])
			{
				divSTDItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divSTDItemIcon.style.backgroundRepeat = "no-repeat";
				divSTDItem.style.color = "rgb(255, 170, 0)";
				m_SelectedValue = m_STDItems[i];
			}

			this.AddSubItemEvent(divSTDItem);
			
			divSTDContent.appendChild(divSTDItem);
		}
		
		if (m_STDItems.length < 6)
		{
			for (var k = m_STDItems.length; k < 6; k++)
			{
				var divSTDItem = document.createElement("DIV");
				divSTDItem.className = "DIV_DLG_ITEM";
				divSTDItem.style.top = (k * 44) + "px";
				divSTDItem.id = i + "_GAMMA_STD_ITEM";
				if (k % 2 == 0)
				{
					j(divSTDItem).css("background-color","rgb(28,28,28)");
				}
				divSTDContent.appendChild(divSTDItem);
			}
		}
		m_SubContentArray.push(divSTDContent);
		
			
			
		var divHGContent = document.createElement("DIV");
		divHGContent.className = "DIV_DLG_ITEMAREA";
		divHGContent.style.display = "none";
		if (m_HGItems.length > 6)
		{
			divHGContent.style.overflowY = "scroll";
		}
		else
		{
			divHGContent.style.overflowY = "hidden";
		}
		
		for (var i = 0; i < m_HGItems.length; i++) {
			var divHGItem = document.createElement("DIV");
			divHGItem.className = "DIV_DLG_ITEM";
			divHGItem.style.top = (i * 44) + "px";
			divHGItem.innerHTML = m_HGItems[i];
			divHGItem.id = i + "_GAMMA_HyperGamma_ITEM";
			if (i % 2 == 0)
			{
				j(divHGItem).css("background-color","rgb(28,28,28)");
			}
			
			if (m_HGItems.length > 6)
			{
				divHGItem.style.width = "196px";
			}
			else
			{
				divHGItem.style.width = "208px";
			}
			
			var divHGItemIcon = document.createElement("DIV");
			divHGItemIcon.className = "DIV_DLG_ITEM_ICON";
			divHGItemIcon.id = i + "_GAMMA_HGITEM_ICON";
			
			divHGItem.appendChild(divHGItemIcon);
			divHGContent.appendChild(divHGItem);
			
			if (m_SelectedValue == m_HGItems[i])
			{
				divHGItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divHGItemIcon.style.backgroundRepeat = "no-repeat";
				divHGItem.style.color = "rgb(255, 170, 0)";
				m_SelectedValue = m_HGItems[i];
			}

			this.AddSubItemEvent(divHGItem);
		}
		
		if (m_HGItems.length < 6)
		{
			for (var k = m_HGItems.length; k < 6; k++)
			{
				var divHGItem = document.createElement("DIV");
				divHGItem.className = "DIV_DLG_ITEM";
				divHGItem.style.top = (k * 44) + "px";
				divHGItem.id = i + "_GAMMA_HyperGamma_ITEM";
				if (k % 2 == 0)
				{
					j(divHGItem).css("background-color","rgb(28,28,28)");
				}			
				divHGContent.appendChild(divSTDItem);
			}
		}
		
		m_SubContentArray.push(divHGContent);
		
		var divUserContent = document.createElement("DIV");
		divUserContent.className = "DIV_DLG_ITEMAREA";
		divUserContent.style.display = "none";
		if (m_UserItems.length > 6)
		{
			divUserContent.style.overflowY = "scroll";
		}
		else
		{
			divUserContent.style.overflowY = "hidden";
		}
		
		for (var i = 0; i < m_UserItems.length; i++) {
			var divUserItem = document.createElement("DIV");
			divUserItem.className = "DIV_DLG_ITEM";
			divUserItem.style.top = (i * 44) + "px";
			divUserItem.innerHTML = m_UserItems[i];
			divUserItem.id = i + "_GAMMA_USER_ITEM";
			if (i % 2 == 0)
			{
				j(divUserItem).css("background-color","rgb(28,28,28)");
			}
			
			if (m_UserItems.length > 6)
			{
				divUserItem.style.width = "196px";
			}
			else
			{
				divUserItem.style.width = "208px";
			}
			
			var divUserItemIcon = document.createElement("DIV");
			divUserItemIcon.className = "DIV_DLG_ITEM_ICON";
			divUserItemIcon.id = i + "_GAMMA_USERITEM_ICON";
			
			divUserItem.appendChild(divUserItemIcon);
			divUserContent.appendChild(divUserItem);
			
			if (m_SelectedValue == m_UserItems[i])
			{
				divUserItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				divUserItemIcon.style.backgroundRepeat = "no-repeat";
				divUserItem.style.color = "rgb(255, 170, 0)";
				m_SelectedValue = m_UserItems[i];
			}

			this.AddSubItemEvent(divUserItem);
		}
		
		if (m_UserItems.length < 6)
		{
			for (var k = m_UserItems.length; k < 6; k++)
			{
				var divUserItem = document.createElement("DIV");
				divUserItem.className = "DIV_DLG_ITEM";
				divUserItem.style.top = (k * 44) + "px";
				divUserItem.id = i + "_GAMMA_USER_ITEM";
				if (k % 2 == 0)
				{
					j(divUserItem).css("background-color","rgb(28,28,28)");
				}			
				divUserContent.appendChild(divUserItem);
			}
		}
		m_SubContentArray.push(divUserContent);	

		// Create S-log2 Content Begin
		var divSLOG2Content = document.createElement("DIV");
		divSLOG2Content.className = "DIV_DLG_ITEMAREA";
		divSLOG2Content.style.display = "none";
		if (m_SLOG2Items.length > 6)
		{
			divSLOG2Content.style.overflowY = "scroll";
		}
		else
		{
			divSLOG2Content.style.overflowY = "hidden";
		}
		
		var divSLOG2Item = document.createElement("DIV");
		divSLOG2Item.className = "DIV_DLG_ITEM";
		divSLOG2Item.innerHTML = m_SLOG2Items[0];
		divSLOG2Item.id = "0_GAMMA_S-LOG2_ITEM";
		if (0 % 2 == 0)
		{
			j(divSLOG2Item).css("background-color","rgb(28,28,28)");
		}
		
		if (m_SLOG2Items.length > 6)
		{
			divSLOG2Item.style.width = "196px";
		}
		else
		{
			divSLOG2Item.style.width = "208px";
		}
		
		var divSLOG2ItemIcon = document.createElement("DIV");
		divSLOG2ItemIcon.className = "DIV_DLG_ITEM_ICON";
		divSLOG2ItemIcon.id = "0_GAMMA_SLOG2ITEM_ICON";
		divSLOG2Item.appendChild(divSLOG2ItemIcon);

		if (m_SelectedValue == m_SLOG2Items[0])
		{
			divSLOG2ItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			divSLOG2Item.style.color = "rgb(255, 170, 0)";
			divSLOG2ItemIcon.style.backgroundRepeat = "no-repeat";
			m_SelectedValue = m_SLOG2Items[0];
		}

		this.AddSubItemEvent(divSLOG2Item);
		
		divSLOG2Content.appendChild(divSLOG2Item);
		
		if (m_SLOG2Items.length < 6)
		{
			for (var k = m_SLOG2Items.length; k < 6; k++)
			{
				var divSLOG2Item = document.createElement("DIV");
				divSLOG2Item.className = "DIV_DLG_ITEM";
				divSLOG2Item.style.top = (k * 44) + "px";
				divSLOG2Item.id = k + "_GAMMA_S-LOG2_ITEM";
				if (k % 2 == 0)
				{
					j(divSLOG2Item).css("background-color","rgb(28,28,28)");
				}			
				divSLOG2Content.appendChild(divSLOG2Item);
			}
		}

		m_SubContentArray.push(divSLOG2Content);
		// Create S-log2 Content end

		// Create S-log3 Content start
		var divSLOG3Content = document.createElement("DIV");
		divSLOG3Content.className = "DIV_DLG_ITEMAREA";
		divSLOG3Content.style.display = "none";
		if (m_SLOG3Items.length > 6) {
			divSLOG3Content.style.overflowY = "scroll";
		} else {
			divSLOG3Content.style.overflowY = "hidden";
		}
		
		var divSLOG3Item = document.createElement("DIV");
		divSLOG3Item.className = "DIV_DLG_ITEM";
		divSLOG3Item.innerHTML = m_SLOG3Items[0];
		divSLOG3Item.id = "0_GAMMA_S-LOG3_ITEM";
		if (0 % 2 == 0)
		{
			j(divSLOG3Item).css("background-color","rgb(28,28,28)");
		}
		
		if (m_SLOG3Items.length > 6)
		{
			divSLOG3Item.style.width = "196px";
		}
		else
		{
			divSLOG3Item.style.width = "208px";
		}
		
		var divSLOG3ItemIcon = document.createElement("DIV");
		divSLOG3ItemIcon.className = "DIV_DLG_ITEM_ICON";
		divSLOG3ItemIcon.id = "0_GAMMA_SLOG3ITEM_ICON";
		divSLOG3Item.appendChild(divSLOG3ItemIcon);

		if (m_SelectedValue == m_SLOG3Items[0])
		{
			divSLOG3ItemIcon.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			divSLOG3Item.style.color = "rgb(255, 170, 0)";
			divSLOG3ItemIcon.style.backgroundRepeat = "no-repeat";
			m_SelectedValue = m_SLOG3Items[0];
		}

		this.AddSubItemEvent(divSLOG3Item);
		
		divSLOG3Content.appendChild(divSLOG3Item);
		
		if (m_SLOG3Items.length < 6)
		{
			for (var k = m_SLOG3Items.length; k < 6; k++)
			{
				var divSLOG3Item = document.createElement("DIV");
				divSLOG3Item.className = "DIV_DLG_ITEM";
				divSLOG3Item.style.top = (k * 44) + "px";
				divSLOG3Item.id = k + "_GAMMA_S-LOG3_ITEM";
				if (k % 2 == 0)
				{
					j(divSLOG3Item).css("background-color","rgb(28,28,28)");
				}			
				divSLOG3Content.appendChild(divSLOG3Item);
			}
		}

		m_SubContentArray.push(divSLOG3Content);
		// S-log3 Content end
		
		divTitle.className = "DIV_DLG_TITLE";
		m_ObjTitle = divTitle;
		
	
		var divOKButton = document.createElement("DIV");
		divOKButton.className = "DIV_DLG_BUTTON";
		divOKButton.innerHTML = "OK";
		divOKButton.style.zIndex = 2;
		divOKButton.style.left = 158 + "px";
		divOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divOKButton.style.top = 266 + "px";
		m_OKButton = divOKButton;
		
		this.AddButtonEvent(divOKButton);

		var divNoButton = document.createElement("DIV");
		divNoButton.className = "DIV_DLG_BUTTON";
		divNoButton.innerHTML = "Cancel";
		divNoButton.style.left = -4 + "px";
		divNoButton.id = "2_DIV_" + this.NameID + "_DLG_BTN";
		divNoButton.style.top = 266 + "px";
		m_CancelButton = divNoButton;
	
		this.AddButtonEvent(divNoButton);

		var divSubOKButton = document.createElement("DIV");
		divSubOKButton.className = "DIV_DLG_BUTTON";
		divSubOKButton.innerHTML = "OK";
		divSubOKButton.style.zIndex = 2;
		divSubOKButton.style.left = 158 + "px";
		divSubOKButton.id = "1_DIV_" + this.NameID + "_DLG_BTN";
		divSubOKButton.style.top = 266 + "px";
		m_SubOKButton = divOKButton;
		
		this.AddButtonEvent(divSubOKButton);
		
		var divBackButton = document.createElement("DIV");
		divBackButton.className = "DIV_DLG_BACK_BTN";
		divBackButton.innerHTML = "Back";
		divBackButton.style.zIndex = 2;
		divBackButton.id = "0_DIV_" + this.NameID + "_DLG_BTN";
		divBackButton.style.top = 266 + "px";
		m_BackButton = divBackButton;
		
		this.AddButtonEvent(divBackButton);
		
		divContainer.appendChild(divTopSeparator);	
		divContainer.appendChild(divMainSubContainer);
		divContainer.appendChild(divBottomSeparator);
		divContainer.appendChild(divSTDContent);
		divContainer.appendChild(divHGContent);
		divContainer.appendChild(divUserContent);
		divContainer.appendChild(divSLOG2Content);
		divContainer.appendChild(divSLOG3Content);
		divContainer.appendChild(divNoButton);
		divContainer.appendChild(divOKButton);
		divContainer.appendChild(divBackButton);
		divContainer.appendChild(divSubOKButton);		
		
		$("DIV_MAIN_CONTAINER").appendChild(divMainContainer);
	}
	
	this.ShowDialog = function()
	{
		if ((arguments.length != 0) && (false == arguments[0]))
		{
			if (m_MainContainer.style.display == "block")
			{
				$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			}
			m_MainContainer.style.display = "none";
			m_MainItemClicked = false;
			m_OKButton.style.display = "none";
			m_CancelButton.style.display = "none";
			m_BackButton.style.display = "none";
			m_SubOKButton.style.display = "none";
			m_IsFirstDisplay = false;
			return;
		}
		
		if (m_MainContainer.style.display == "block")
		{
			m_MainContainer.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			this.IsDisplay = false;
			m_IsFirstDisplay = false;
		}
		else
		{
			m_IsFirstDisplay = true;
			m_MainContainer.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
			m_OKButton.style.display = "block";
			m_CancelButton.style.display = "block";
			for (var k = 0; k < m_SubContentArray.length; ++k)
			{
				j(m_SubContentArray[k]).hide();
			}
			
			m_MainContent.style.display = "block";
			var index = j.inArray(m_MainSelectedType,m_GammaTypeItems);
			for (var i = 0; i < m_GammaTypeItems.length; ++i)
			{
				m_MainContent.children[i].style.color = "rgb(230,230,230)";
				m_MainContent.children[i].children[0].style.backgroundImage = "";
				if (index == i)
				{
					m_MainContent.children[i].style.color = "rgb(255,170,0)";
					m_MainContent.children[i].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				}
			}
			if (m_IsFirstDisplay)
			{
				m_OldGammaType = m_MainSelectedType;
			}			
		}
		m_MainItemClicked = false;
		m_BackButton.style.display = "none";
		m_SubOKButton.style.display = "none";
	}
	
	this.CallbackMainItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_GAMMA_ARROW") || (objSrc.id == "1_GAMMA_ARROW")
				|| (objSrc.id == "2_GAMMA_ARROW") || (objSrc.id == "3_GAMMA_ARROW") || (objSrc.id == "4_GAMMA_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		
		if (parseInt(objSrc.id) == m_MainSelectedTypeIndex) {
			objSrc.style.color = "rgb(255,170,0)";
		} else {
			objSrc.style.color = "rgb(230,230,230)";
		}
		if (parseInt(objSrc.id) % 2 == 0) {
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		} else {
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackMainItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_GAMMA_ARROW") || (objSrc.id == "1_GAMMA_ARROW") 
			|| (objSrc.id == "2_GAMMA_ARROW") || (objSrc.id == "3_GAMMA_ARROW") || (objSrc.id == "4_GAMMA_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";
		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		if(m_BackGammaItem != null && m_BackGammaItem != objSrc)
		{
			m_BackGammaItem.children[0].style.backgroundImage = "";
			m_BackGammaItem.style.color = "rgb(230,230,230)";
		}
	};

	this.CallbackMainItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_GAMMA_ARROW") || (objSrc.id == "1_GAMMA_ARROW") 
			|| (objSrc.id == "2_GAMMA_ARROW") || (objSrc.id == "3_GAMMA_ARROW")|| (objSrc.id == "4_GAMMA_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(255,170,0)";
		/*if (parseInt(objSrc.id) == m_MainSelectedTypeIndex)//selected Type
		{
			objSrc.style.color = "rgb(255,170,0)";
			//objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		} 
		else 
		{
			objSrc.style.color = "rgb(230,230,230)";
		}*/
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		} 
		else 
		{
			objSrc.style.backgroundColor = "";
		}
	};
	
	this.CallbackMainItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_GAMMA_ARROW") || (objSrc.id == "1_GAMMA_ARROW")
			|| (objSrc.id == "2_GAMMA_ARROW") || (objSrc.id == "3_GAMMA_ARROW") || (objSrc.id == "4_GAMMA_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";
		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		if(m_BackGammaItem != null && m_BackGammaItem != objSrc)
		{
			m_BackGammaItem.children[0].style.backgroundImage = "";
			m_BackGammaItem.style.color = "rgb(230,230,230)";
		}
	};
	
	this.CallbackMainItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes() || (objSrc.id == "0_GAMMA_ARROW") || (objSrc.id == "1_GAMMA_ARROW")
			|| (objSrc.id == "2_GAMMA_ARROW") || (objSrc.id == "3_GAMMA_ARROW") || (objSrc.id == "4_GAMMA_ARROW"))
		{
			objSrc = GetParent(objSrc);
		}
		
		objSrc.style.color = "rgb(255,170,0)"; //change color to yellow
		/*if (parseInt(objSrc.id) == m_MainSelectedTypeIndex)				//selected Type
		{
			objSrc.style.color = "rgb(255,170,0)";
		} 
		else 
		{
			objSrc.style.color = "rgb(230,230,230)";
		}*/
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		} 
		else {
			objSrc.style.backgroundColor = "";
		}
		
		m_MainSelectedTypeIndex = parseInt(objSrc.id); 
		m_MainSelectedType = m_GammaTypeItems[m_MainSelectedTypeIndex];
		var tempType = m_MainSelectedType;
		if ("HG" == m_MainSelectedType)
		{
			tempType = "HyperGamma";
		}
		else if ("S-Log2" == m_MainSelectedType)
		{
			//tempType = "S-LOG2";
		}
		else if ("S-Log3" == m_MainSelectedType)
		{
			//tempType = "S-LOG3";
		}
		if (null != m_objSelf.CallbackFunc)
		{
			m_objSelf.CallbackFunc(true, tempType, "");
		}
		//m_objSelf.ShowSubContent();
		this.IsDisplay = true;
		m_MainItemClicked = true;
	};

	
	this.CallbackMainItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}

		m_MainSelectedTypeIndex = parseInt(objSrc.id); 
		m_MainSelectedType = m_GammaTypeItems[m_MainSelectedTypeIndex];
		var tempType = m_MainSelectedType;
		if ("HG" == m_MainSelectedType)
		{
			tempType = "HyperGamma";
		}
		else if ("S-Log2" == m_MainSelectedType)
		{
			//tempType = "S-LOG2";
		}
		else if("S-Log3" == m_MainSelectedType)
		{
			//tempType = "S-LOG3";
		}
		if (null != m_objSelf.CallbackFunc)
		{
			m_objSelf.CallbackFunc(true, tempType, "");
		}
		//m_objSelf.ShowSubContent();
		this.IsDisplay = true;
		m_MainItemClicked = true;
	}

	this.ShowSubContent = function()
	{
		if (m_MainSelectedType == "S-Log3")
		{
			return;
		}
		var index = -1;
		m_MainContent.style.display = "none";
		m_OKButton.style.display = "none";
		m_CancelButton.style.display = "none";
		m_BackButton.style.display = "block";
		m_SubOKButton.style.display = "block";
		m_objSelf.CleanSelection(m_MainSelectedType);				//clean selection
		m_OldGammaValue = m_SelectedValue;
		switch (m_MainSelectedType)
		{
			case "STD":
			m_SubContentArray[0].style.display = "block";
			m_MainSelectedTypeIndex = 0;
			m_MainSelectedType = "STD";
			index = j.inArray(m_SelectedValue, m_STDItems);
			if (-1 != index)
			{
				m_SubContentArray[0].children[index].style.color = "rgb(255,170,0)";
				m_SubContentArray[0].children[index].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			}
			break;
			case "HG":
			m_SubContentArray[1].style.display = "block";
			m_MainSelectedTypeIndex = 1;
			m_MainSelectedType = "HG";
			index = j.inArray(m_SelectedValue, m_HGItems);
			if (-1 != index)
			{
				m_SubContentArray[1].children[index].style.color = "rgb(255,170,0)";
				m_SubContentArray[1].children[index].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			}
			break;
			case "User":
			m_SubContentArray[2].style.display = "block";
			m_MainSelectedTypeIndex = 2;
			m_MainSelectedType = "User";
			index = j.inArray(m_SelectedValue, m_UserItems);
			if (-1 != index)
			{
				m_SubContentArray[2].children[index].style.color = "rgb(255,170,0)";
				m_SubContentArray[2].children[index].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			}
			break;			
			/*case "S-Log2":
			m_SubContentArray[3].style.display = "block";
			m_MainSelectedTypeIndex = 3;
			m_MainSelectedType = "S-Log2";
			index = j.inArray(m_SelectedValue, m_SLOG2Items);
			if (-1 != index)
			{
				m_SubContentArray[3].children[index].style.color = "rgb(255,170,0)";
				m_SubContentArray[3].children[index].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			}
			break;
			case "S-Log3":
			m_SubContentArray[4].style.display = "block";
			m_MainSelectedTypeIndex = 4;
			m_MainSelectedType = "S-Log3";
			index = j.inArray(m_SelectedValue, m_SLOG3Items);
			if (-1 != index)
			{
				m_SubContentArray[4].children[index].style.color = "rgb(255,170,0)";
				m_SubContentArray[4].children[index].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
			}
			break;*/
			default:
			break;
		}
		m_MainItemClicked = false;
	}

	this.CallbackSubItemMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (j(objSrc).text() == m_SelectedValue)			//selected Value
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if ((j(objSrc).text() == "S-Log2") && (m_SelectedValue == "S-LOG2"))
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		if ((j(objSrc).text() == "S-Log3") && (m_SelectedValue == "S-LOG3"))
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		if (parseInt(objSrc.id) % 2 == 0) {
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		} else {
			objSrc.style.backgroundColor = "";
		}
		
	};
	
	this.CallbackSubItemMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};

	this.CallbackSubItemMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		
		if (j(objSrc).text() == m_SelectedValue)		//selected Value
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		else
		{
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if ((j(objSrc).text() == "S-Log2") && (m_SelectedValue == "S-LOG2"))
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		if ((j(objSrc).text() == "S-Log3") && (m_SelectedValue == "S-LOG3"))
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		}
		else
		{
			objSrc.style.backgroundColor = "";
		}	
	};
	
	this.CallbackSubItemTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objEvent.preventDefault();
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}
		objSrc.style.color = "rgb(0,0,0)";
		objSrc.style.backgroundColor = "rgb(255,170,0)";	
	};
	
	this.CallbackSubItemTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}

		if (j(objSrc).text() == m_SelectedValue)			//selected Value
		{
			objSrc.style.color = "rgb(255,170,0)";
		} else {
			objSrc.style.color = "rgb(230,230,230)";
		}
		
		if ((j(objSrc).text() == "S-Log2") && (m_SelectedValue == "S-LOG2"))
		{
			objSrc.style.color = "rgb(255,170,0)";
		}
		if (parseInt(objSrc.id) % 2 == 0)
		{
			objSrc.style.backgroundColor = "rgb(28,28,28)";
		} else {
			objSrc.style.backgroundColor = "";
		}

		m_objSelf.CleanSelection(m_MainSelectedType);				//clean selection
		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		objSrc.style.color = "rgb(255, 170, 0)";
		m_SelectedValue = j(objSrc).text();
		
		if (null != m_objSelf.CallbackFunc)
		{
			var tempValue = m_SelectedValue;
			if ("S-Log2" == m_SelectedValue)
			{
			}
			if ("S-Log3" == m_SelectedValue)
			{
			}
			m_objSelf.CallbackFunc(true, m_MainSelectedType, tempValue);
		}
	};	

	this.CallbackSubItemClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		m_objSelf.CleanSelection(m_MainSelectedType);			//clean selection
		if (!objSrc.hasChildNodes())
		{
			objSrc = GetParent(objSrc);
		}

		objSrc.children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
		objSrc.style.color = "rgb(255, 170, 0)";
		m_SelectedValue = j(objSrc).text();
		
		if (null != m_objSelf.CallbackFunc)
		{
			var tempValue = m_SelectedValue;
			if ("S-Log2" == m_SelectedValue)
			{
			}
			if ("S-Log3" == m_SelectedValue)
			{
			}
			m_objSelf.CallbackFunc(true, m_MainSelectedType, tempValue);
		}
	};
	
	this.CallbackButtonClick = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);

		m_MainItemClicked = false;		
		if (1 == parseInt(objSrc.id))					//OK Button
		{
			m_MainContainer.style.display = "none";
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			m_IsFirstDisplay = false;
			g_OldObject = null;
		} 
		else if (0 == parseInt(objSrc.id))				//Back Button
		{
			var index = j.inArray(m_MainSelectedType,m_GammaTypeItems);
			for (var i = 0; i < m_GammaTypeItems.length; ++i)
			{
				m_MainContent.children[i].style.color = "rgb(230,230,230)";
				m_MainContent.children[i].children[0].style.backgroundImage = "";
				if (index == i)
				{
					m_BackGammaItem = m_MainContent.children[i];
					m_MainContent.children[i].style.color = "rgb(255,170,0)";
					m_MainContent.children[i].children[0].style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_SelectMark_Serected.png)";
				}
			}				
			for(var k = 0; k< m_SubContentArray.length; ++k)
			{
				m_SubContentArray[k].style.display = "none";	
			}
			m_MainContent.style.display = "block";
			$("DIV_BUTTON_MASKDIALOG").style.display = "block";
			m_OKButton.style.display = "block";
			m_CancelButton.style.display = "block";
			
			m_BackButton.style.display = "none";
			m_SubOKButton.style.display = "none";
		}
		else //cancel
		{
			$("DIV_BUTTON_MASKDIALOG").style.display = "none";
			m_MainContainer.style.display = "none";
			m_IsFirstDisplay = false;
			if (null != m_objSelf.CallbackFunc)
			{
				var tempType = m_OldGammaType;
				if ("HG" == m_OldGammaType)
				{
					tempType = "HyperGamma";
				}
				else if ("S-Log2" == m_OldGammaType)
				{
					//tempType = "S-LOG2";
				}
				else if("S-Log3" == m_OldGammaType)
				{
					//tempType = "S-LOG3";
				}
				m_objSelf.CallbackFunc(true, tempType, "");
				m_MainSelectedType = m_OldGammaType;
			}
			g_OldObject = null;
		}
	};
	
	this.CallbackBtnTouchStart = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		objEvent.preventDefault();
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";
		}
		objSrc.style.color = "rgb(0,0,0)";
	};
	
	this.CallbackBtnTouchEnd = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
	
			
	if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
		
		m_objSelf.CallbackButtonClick(objEvent);
	};

	this.CallbackButtonMouseOut = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
	};
	
	this.CallbackButtonMouseDown = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);	
		
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Pressed.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Pressed.png)";
		}
		objSrc.style.color = "rgb(0,0,0)";
	};

	this.CallbackButtonMouseUp = function(objEvent)
	{
		var objSrc = GetEventSource(objEvent);
		if ((1 == parseInt(objSrc.id)) || (2 == parseInt(objSrc.id)))
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Normal.png)";
		}
		else
		{
			objSrc.style.backgroundImage = "URL(PhoneCommon/images/Parts_CR_S_CC_Spinner_Button_Back_Normal.png)";
		}
		objSrc.style.color = "rgb(230,230,230)";
	};
	

	
	this.SetTitle = function(strTitle)
	{
		m_ObjTitle.innerHTML = strTitle;
	};
	
	this.CleanSelection = function(selectedType)
	{
		switch (selectedType)
		{
			case "STD":
			for (var i = 0; i < m_STDItems.length; ++i)
			{
				m_SubContentArray[0].children[i].style.color = "rgb(230,230,230)";
				m_SubContentArray[0].children[i].children[0].style.backgroundImage = "";				
			}
			break;
			case "HG":
			for (var j = 0; j < m_HGItems.length; ++j)
			{
				m_SubContentArray[1].children[j].style.color = "rgb(230,230,230)";
				m_SubContentArray[1].children[j].children[0].style.backgroundImage = "";				
			}
			break;
			case "User":
			for (var m = 0; m < m_UserItems.length; ++m)
			{
				m_SubContentArray[2].children[m].style.color = "rgb(230,230,230)";
				m_SubContentArray[2].children[m].children[0].style.backgroundImage = "";				
			}
			break;
			case "S-Log2":
			for (var k = 0; k < m_SLOG2Items.length; ++k)
			{
				m_SubContentArray[3].children[k].style.color = "rgb(230,230,230)";
				m_SubContentArray[3].children[k].children[0].style.backgroundImage = "";				
			}
			break;
			case "S-Log3":
			for (var n = 0; n < m_SLOG3Items.length; ++n)
			{
				m_SubContentArray[4].children[n].style.color = "rgb(230,230,230)";
				m_SubContentArray[4].children[n].children[0].style.backgroundImage = "";				
			}
			break;
			default:
			break;	
		}
	}
	
	this.IsDialogShow = function()
	{
		var b_IsDialogShow = true;
		if(m_MainContainer.style.display == "none")
		{
			b_IsDialogShow = false;
		}
		return b_IsDialogShow;
	};
	
	this.SetGammaType = function(selectedType)
	{
		if ("STD" == selectedType)
		{
			m_BackGammaItem = m_MainContent.children[0];
		}
		else if ("HyperGamma" == selectedType)
		{
			selectedType = "HG";
			m_BackGammaItem = m_MainContent.children[1];
		}
		else if ("User" == selectedType)
		{
			m_BackGammaItem = m_MainContent.children[2];
		}
		else if ("S-LOG2" == selectedType || "S-Log2" == selectedType)
		{
			selectedType = "S-Log2";
			m_BackGammaItem = m_MainContent.children[3];
		}
		else if("S-LOG3" == selectedType || "S-Log3" == selectedType)
		{
			selectedType = "S-Log3";
			m_BackGammaItem = m_MainContent.children[4];
		}
		m_MainSelectedType = selectedType;
		m_MainSelectedTypeIndex = j.inArray(m_MainSelectedType,m_GammaTypeItems);
	}
	
	this.SetSelect = function(selectedValue)
	{
		if ("S-LOG2" == selectedValue)
		{
			selectedValue = "S-Log2";
		}
		else if("S-LOG3" == selectedValue)
		{
			selectedValue = "S-Log3";
		}
		m_SelectedValue = selectedValue;
		//alert("m_MainItemClicked = "+m_MainItemClicked)
		if ((m_MainItemClicked == true) && ("S-Log3" != m_MainSelectedType) && ("S-Log2" != m_MainSelectedType))
		{	
			m_objSelf.ShowSubContent();
		}
	};
	
	this.AddSubItemEvent = function(divSubItem)
	{
		AddEvent(divSubItem, "click", this.CallbackSubItemClick);
		AddEvent(divSubItem, "mouseover", this.CallbackSubItemMouseOver);
		AddEvent(divSubItem, "mouseout", this.CallbackSubItemMouseOut);
		AddEvent(divSubItem, "mousedown", this.CallbackSubItemMouseDown);
		AddEvent(divSubItem, "mouseup", this.CallbackSubItemMouseUp);
		AddEvent(divSubItem, "touchstart", this.CallbackSubItemTouchStart);	
		AddEvent(divSubItem, "touchend", this.CallbackSubItemTouchEnd);
		AddEvent(divSubItem, "touchcancel", this.CallbackSubItemTouchEnd);	
	}
	
	this.AddButtonEvent = function(divButton)
	{
		AddEvent(divButton, "click", this.CallbackButtonClick);
		AddEvent(divButton, "mouseover", this.CallbackButtonMouseOver);
		AddEvent(divButton, "mouseout", this.CallbackButtonMouseOut);
		AddEvent(divButton, "mousedown", this.CallbackButtonMouseDown);
		AddEvent(divButton, "mouseup", this.CallbackButtonMouseUp);	
		AddEvent(divButton, "touchstart", this.CallbackBtnTouchStart);	
		AddEvent(divButton, "touchend", this.CallbackBtnTouchEnd);
		AddEvent(divButton, "touchcancel", this.CallbackBtnTouchCancel);	
	}
	
	this.CallbackEmptyTouchEvent = function CallbackEmptyTouchEvent(objEvent)
	{
		objEvent.preventDefault();
	};
	
	this.Create();
}
